﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "../CustomBasePawn.h"
#include "../../Component/ViewBlend/ViewBlendComponent.h"
#include "GameFramework/Pawn.h"
#include "Curves/RichCurve.h"
#include "Components/TimelineComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "CommonGamePlayToolPlugin/Interface/ReceiveInputInterface.h"
#include "CommonGamePlayToolPlugin/Interface/RegisterInputInterface.h"
#include "CommonGamePlayToolPlugin/Type/CommonEnumType.h"
#include "CommonBasePawn.generated.h"


UENUM(BlueprintType)
enum ECurrentActiveCamera:uint8
{
	All_Camera_Active,				//所有的相机都处于激活状态
	Only_SpringArm_Camera_Active,	//只有SpringArm_Camera相机处于激活状态
	Only_Normal_Camera_Active,		//只有Normal_Camera相机处于激活状态
	No_Camera_Active				//没有相机处于激活状态
};

UCLASS(Blueprintable,BlueprintType)
class COMMONGAMEPLAYTOOLPLUGIN_API ACommonBasePawn :public ACustomBasePawn,
													public IReceiveInputInterface,
													public IRegisterInputInterface
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	ACommonBasePawn(const FObjectInitializer& ObjectInitializer);
	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	/* 该方法用于在SetupPlayerInputComponent方法中调用,以供蓝图扩展调用 */
	UFUNCTION(BlueprintImplementableEvent,Category="ACommonBasePawn")
	void SetupPlayerInputComponentInternalEvent();

	/* 仅用于测试显示当前可识别的输入 */
	UFUNCTION(BlueprintPure,meta=(DevelopmentOnly),Category="ACommonBasePawn")
	int32 GetAllInput();

//输入注册	
#pragma region IRegisterInputInterface接口
public:	
	virtual void RegisterInputEvent_Implementation() override;
#pragma endregion

//对接收的输入作出反应	
#pragma region IReceiveInputInterface接口
public:
	/* 接收输入事件 */
	virtual void ReceiveInputEvent_Implementation(const FVector2D& Value)override;

	/* 接收输入进行旋转事件 */
	virtual void ReceiveInputRotateEvent_Implementation(const FVector2D& Value)override;

	/* 接收输入进行移动事件 */
	virtual void ReceiveInputMoveEvent_Implementation(const FVector2D& Value) override;

	/* 接收输入进行视角缩放事件 */
	virtual void ReceiveInputViewZoomEvent_Implementation(const float Value) override;
	
#pragma endregion

//Pawn上的组件
#pragma region Pawn相关组件
public:	
	/* Pawn的根组件 */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn")
	USceneComponent* Scene;

	/* 弹簧臂组件,用于鸟瞰形式的移动 */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn")
	USpringArmComponent* SpringArm;

	/* 挂在弹簧臂上的相机,用于鸟瞰形式的移动 */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn")
	UCameraComponent* SpringArmCamera;
	
	/* 普通的弹簧臂组件 */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn")
	USpringArmComponent* NormalCameraSpringArm;
	
	/* 用于第一人称形式的移动 */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn")
	UCameraComponent* NormalCamera;

	/* 用于缩放形式的移动和旋转的弹簧臂 */
	//UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn")
	//USpringArmComponent* ZoomSpringArm;

	/* 用于缩放形式的移动和旋转的相机 */
	//UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn")
	//UCameraComponent* ZoomCamera;

	

	

	

	
#pragma endregion

//位置移动
#pragma region 移动
public:
	/* bCan_Move用于条件判断,控制Pawn是否可以在接收输入之后进行移动 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	uint32 bCanMove:1=1;

	/* SpringArmCamera移动速度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	FVector2D SpringArmCameraMoveParam=FVector2D(1.f,1.f);

	/* SpringArmCamera移动速度曲线 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	UCurveVector* SpringArmCameraMoveSpeedCurve=nullptr;

	/* SpringArmCamera移动速度曲线 */
	UFUNCTION(BlueprintPure,Category="ACommonBasePawn|Move")
	FVector2D GetSpringArmCameraMoveSpeed(const float Value) const;
	
	/* NormalCamera移动速度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	FVector2D NormalCameraMoveSpeed=FVector2D(1.f,1.f);
	
	/* 是否限制Pawn的移动范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	uint32 bCanLimitMoveRange:1=1;

	/* 用于表名SpringArmCamera当前移动是否为切换相机后的第一帧 */
	uint32 bSpringArmCameraFirstFrameMove:1=0;
	
	/* 限制移动的矩形范围偏移角度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	float MoveOffsetAngle=0.f;
	
	/* X方向上的移动范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	FVector2D XMoveRange=FVector2D(-1000000,-1000000);
	
	/* Y方向上的移动范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	FVector2D YMoveRange=FVector2D(-1000000,1000000);

	/* Z方向上的移动范围,当使用鸟瞰的移动方式时,使用最底点的位置 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Move")
	FVector2D ZMoveRange=FVector2D(500,1000);

	/* 用于使用普通相机时的Pawn移动 */
    UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Move")
    void NormalCameraMoveEvent(const FVector2D& Value);

	/* SpringArm_Camera接收FVector2D输入来进行移动 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Move")
	void SpringArmCameraMoveEvent(const FVector2D& Value);

	/* 当Normal_Camera相机和SpringArm_Camera相机都未激活时调用 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn")
	void NoCameraMoveEvent(const FVector2D& Value);

	/* 当Normal_Camera相机和SpringArm_Camera相机都激活时调用 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn")
	void AllCameraMoveEvent(const FVector2D& Value);
#pragma endregion

//方向旋转
#pragma region 旋转
public:	
	/* bCanRotate用于条件判断,控制Pawn是否可以在接收输入之后进行旋转 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	uint32 bCanRotate:1=1;

	/* SpringArmCamera旋转速度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	FVector2D SpringArmCameraRotateSpeed=FVector2D(1.f,-1.f);

	/* NormalCamera旋转速度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	FVector2D NormalCameraRotateSpeed=FVector2D(1.f,1.f);
	
	/* 是否启用角度旋转限制 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	uint32 bCanLimitRotate:1=1;
	
	/* SpringArm_Camera旋转Pitch值范围,X值表示最小值,Y值表示最大值 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	FVector2D SpringArmCameraPitchRotateRange=FVector2D(-80.f,-1.f);
	
	/* NormalCamera的Pitch值范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	FVector2D NormalCameraPitchRotateRange=FVector2D(-89.f,89.f);
	
	/* Yaw的角度值范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	FVector2D YawRotateRange=FVector2D(-180,180);

	/* Roll的角度值范围,默认归0 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Rotate")
	FVector2D RollRotateRange=FVector2D(0,0);
	
	/* 用于使用普通相机时的Pawn旋转 */
    UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Rotate")
    void NormalCameraRotateEvent(const FVector2D& Value);

	/* SpringArm_Camera接收FVector2D输入来进行旋转 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void SpringArmCameraRotateEvent(const FVector2D& Value);

	/* 当Normal_Camera相机和SpringArm_Camera相机都未激活时调用 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void NoCameraRotateEvent(const FVector2D& Value);

	/* 当Normal_Camera相机和SpringArm_Camera相机都激活时调用 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void AllCameraRotateEvent(const FVector2D& Value);

	/* 设置弹簧臂相机的角度,会内部处理将Actor的旋转归零,然后设置弹簧臂相机的值 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void SetSpringArmRotation(const FRotator& Rotation);

	/* 获取弹簧臂的角度 */
	UFUNCTION(BlueprintPure,Category="ACommonBasePawn|Rotate")
	FRotator GetSpringArmRotation();
#pragma endregion

//视野FOV	
#pragma region 视野FOV
public:
	/* 设置相机的FOV */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn|FOV")
	void SetCameraFOV(const float Value);

	/* 获取相机的FOV */
	UFUNCTION(BlueprintPure,Category="ACommonBasePawn|FOV")
	float GetCameraFOV();

	/* 重置相机FOV */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn|FOV")
	void ResetCameraFOV();
#pragma endregion

//相机纵横比例
#pragma region 相机纵横比例
public:
	/* 设置相机的纵横比例 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void SetCameraAspectRatio(const float Value);

	/* 关闭相机的纵横比例 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void CloseCameraAspectRatio();

#pragma endregion
	
//视野缩放
#pragma region 缩放
private:
	/* 用于视角拉近和缩远变化的TimeLine */
	UPROPERTY()
	UTimelineComponent* ViewScaleTimeLine=nullptr;

	/* 总的视野缩放更新事件 */
	UFUNCTION()
	void CameraViewScaleUpdateEvent(const float Value);
public:	
	UFUNCTION()
	UTimelineComponent* GetViewScaleTimeLine();
	
	/* 是否允许拉近和拉远视角 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	uint32 bCanViewScale:1=1;
	
	/* NormalCamera是否允许拉近和拉远视角 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	uint32 bNormalCameraCanViewScale:1=1;
	
	/* 是否限制视角缩放 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	uint32 bCanLimitViewScale:1=1;

	/* SpringArmCamera视口缩放速度曲线 */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	UCurveFloat* SpringArmCameraViewScaleSpeedCurve=nullptr;

	/* 视口缩放参数 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	float CameraViewScaleParam=1.0f;
	
	/* SpringArmCamera的弹簧臂取值范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	FVector2D SpringArmCameraSpringArmLengthRange=FVector2D(0.f,2000000.f);

	/* NormalCamera视口缩放的速度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	float NormalCameraViewScaleSpeed=1000.0f;

	/* NormalCamera视口缩放是否启用障碍物阻挡 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|ViewScale")
	uint32 bNormalCameraViewScaleBarrierBlock:1=1;
	
	/* NormalCamera视口缩放事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|ViewScale")
	void NormalCameraViewScaleEvent(const float& Value);

	/* SpringArmCamera视口缩放事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|ViewScale")
    void SpringArmCameraViewScaleEvent(const float& Value);

	/* 当Normal_Camera相机和SpringArm_Camera相机都未激活时调用 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void NoCameraViewScaleEvent(const float& Value);

	/* 当Normal_Camera相机和SpringArm_Camera相机都激活时调用 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Rotate")
	void AllCameraViewScaleEvent(const float& Value);

	/* NormalCamera视口缩放更新事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|ViewScale")
	void NormalCameraCameraViewScaleUpdateEvent(const float Value);
	
	/* SpringArmCamera视口缩放更新事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|ViewScale")
	void SpringArmCameraViewScaleUpdateEvent(const float Value);

	/* 无相机视口缩放更新事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|ViewScale")
	void NoCameraCameraViewScaleUpdateEvent(const float Value);

	/* 所有相机视口缩放更新事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|ViewScale")
    void AllCameraCameraViewScaleUpdateEvent(const float Value);

	/* SpringArmeCamera获取视口缩放的速度 */
	UFUNCTION(BlueprintPure,Category="ACommonBasePawn|ViewScale")
	float GetSpringArmeCameraViewScaleSpeed(const float Value);
#pragma endregion
	
//自动旋转
#pragma region 自动旋转
public:
	/* 是否启用当一段时间未输入时自动旋转 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|AutoRotate")
	uint32 bCanAutoRotate:1=1;

	/* 自动旋转的速度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|AutoRotate",meta=(EditCondition="bCan_AutoRotate"))
	float AutoRotateSpeed=2.0f;

	/* 开始自动旋转的临界时间,当超过该时间时,将自动旋转 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|AutoRotate",meta=(EditCondition="bCan_AutoRotate"))
	float StartAutoRotateTime=15.0f;
	
	/* 当前累计未接收输入的时间 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|AutoRotate",meta=(EditCondition="bCan_AutoRotate"))
	float CurrentNoActionTime=0;

	/* Pawn围绕当前点自动旋转 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|AutoRotate")
	void AutoRoundPointRotateEvent();

	/* 给定一个位置、角度,SpringArm_Camera将绕其旋转 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|AutoRotate")
	void SpringArm_Camera_Round_Point_Rotate_Event(const FVector Location,const FRotator Rotate,const float ViewDistance=3000.f);
	
	/* 重置自动旋转总得计时时间 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|AutoRotate")
	void ResetAutoRotateTotalTime();
#pragma endregion

//开关属性--待完善
#pragma region 开关属性
public:	
	/* bCan_BreakSequencePlay用于条件判断,控制Pawn是否可以在播放Sequence时接收输入之后中断Sequence播放 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Switch")
	uint32 bCanBreakSequencePlay:1=1;

#pragma endregion

//状态属性
#pragma region 状态属性
public:	
	/* 属性表示当前是否正在播放漫游Sequence动画 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|State")
	uint32 bPlayingSequence:1=0;

	/* 属性表示当前是否正在进行视角混合 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|State")
	uint32 bPlayingViewBlend:1=0;
#pragma endregion

//移动方式--待完善
#pragma region 移动方式切换
public:
	/* 初始化移动方式 */
	void InitializeMoveType(const EMoveWayType Value);
	
	/* 切换当前的移动方式 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn")
	void SwitchMoveType(const EMoveWayType Value);
	
	
#pragma endregion

//	--待完善
#pragma region 自动绕点旋转属性
public:	
	
	
	
#pragma endregion

//相机转换	
#pragma region 相机转换
	/* Normal_Camera可以转为SpringArm_Camera时的Pitch值范围,X值表示最小值,Y值表示最大值,最好不要更改 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Convert")
	FVector2D SpringArmCameraConvertPitchRotateRange=FVector2D(-80.f,-1.f);

	/* 在视口缩放时是否自动转换为SpringArmCamera */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Convert")
	uint32 bCanAutoConvertSpringArmCamera:1=1;

	/* 检测当前视口角度是否处于可以从Normal_Camera转为SpingArm_Camera的Pitch角度范围内 */
	UFUNCTION(BlueprintPure,Category="ACommonBasePawn|Convert")
	bool Can_Normal_Camera_To_SpringArm_Camera_Pitch_Range();
	
	/* 用于将普通相机转为弹簧臂相机 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Convert")
	void NormalCameraToSpringArmCamera();

	/* 用于将弹簧臂相机转为普通相机,这不可能会失败 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Convert")
	bool SpringArmCameraToNormalCamera();

	/* 强制转换当前的相机为SpringArm_Camera */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Convert")
	void ForceConvertToSpringArmCamera();

	/* 强制装换当前的相机为SpringArm_Camera并设置其位置和方向 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn|Convert")
	void ForceConvertToSpingArmCameraSetProperty(const FVector Location,const FRotator Rotate,const float ViewDistance=3000.f);
#pragma endregion

//	
#pragma region 处理相关功能需要的属性
public:	
	/* 目标的弹簧臂长度,用于计算使用 */
	float CurrentSpringArm_Length=0.f;
	
	/* 目标的弹簧臂长度,用于计算使用 */
	float TargetSpringArm_Length=0.f;
	
#pragma endregion

//
#pragma region 操作方式
public:	
	/* 当bMove_Action_Type为true时,收到FVector2D输入将进行移动 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Type")
	bool bMove_Action_Type=false;
    
	/* 当bRotate_Action_Type为true时,收到FVector2D输入将进行旋转 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="ACommonBasePawn|Type")
	bool bRotate_Action_Type=false;
#pragma endregion

#pragma region 处理Pawn移动相关
	/* 获取当前处于激活状态的相机状态 */
	UFUNCTION(BlueprintCallable,meta=(ExpandEnumAsExecs="CurrentActiveCamera"),Category="ACommonBasePawn")
	void GetCurrentActiveCamera(TEnumAsByte<ECurrentActiveCamera>& CurrentActiveCamera);
	
	/* 用于确保只有一个Camera处于激活状态 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn")
	void Ensure_Only_One_Camera_Active_Internal();
	
	/* 仅当鼠标左键按下,且鼠标右键未按下时调用 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn")
	void OnOnlyMouseLeftButtonPressed_Internal(const FVector2D& Value);

	/* 仅当鼠标右键按下,且鼠标左键未按下时调用 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn")
	void OnOnlyMouseRightButtonPressed_Internal(const FVector2D& Value);

	/* 当鼠标左键与右键都按下时调用 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn")
	void OnMouseAllButtonPressed_Internal(const FVector2D& Value);


#pragma endregion

#pragma region 视口过渡
	/* 用于记录上一次进行视角混合的标识符 */
	UPROPERTY(BlueprintReadWrite,Category="ACommonBasePawn|BlendView")
	FName LastViewBlendTag;

	/* 用于视口混合Curve */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="ACommonBasePawn|BlendView")
	UCurveFloat* ViewBlendCueve=nullptr;

	/* 用于视口混合时使用的TimeLine */
	UPROPERTY()
	UTimelineComponent* ViewBlendTimeLine;
	
	/* 用于记录需要进行视口混合过渡使用的的起始、结束位置 */
	FVector StartLocation,TargetLocation;
	
	/* 用于记录需要进行视口混合过渡使用的的起始、结束角度 */
	FRotator StartRotate,TargetRotate;

	/* 获取用于视口混合的TimeLine */
	UTimelineComponent* GetViewBlendTimeLine();
	
	/* 直接设置视口的位置角度 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn",DisplayName="SetCameraView")
	void SetCameraView(const FVector& InVector,const FRotator& InRotator,const FName ViewBlendTag=FName(""));

	/* 使用TimeLine对视角进行混合 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn")
	void ViewBlendTimeLinePlay(const FVector& InVector,const FRotator& InRotator,const float BlendTime=1.f,const FName ViewBlendTag=FName(""));

	/* 视口混合TimeLine的更新执行函数 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn")
	void ViewBlendTimeLineUpdateEvent(const float Value);

	/* 视口混合TimeLine的混合完毕执行函数 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ACommonBasePawn")
	void ViewBlendTimeLineEndEvent();
#pragma endregion

//限制移动范围	
#pragma region 限制移动范围
public:
	/* 位置限制在一个圆形范围 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn")
	FVector LimitInCircleRange(const FVector& CurrentLocation,const FVector& CircleCenter,const float& Radius);

	/* 位置限制在一个矩形范围 */
	UFUNCTION(BlueprintCallable,Category="ACommonBasePawn")
	FVector LimitInRectRange(const FVector& CurrentLocation,const FVector2D& XRange,const FVector2D& YRange,const float& YawAngleOffset);
#pragma endregion

#pragma region 内部使用方法
	inline APlayerCameraManager* GetPlayerCameraManager();
#pragma endregion

#pragma region Pawn的控制与取消控制
public:

	
#pragma endregion
	
public:
	//TEnumAsByte<EMoveWayType>CurrentMoveWayType;
};
