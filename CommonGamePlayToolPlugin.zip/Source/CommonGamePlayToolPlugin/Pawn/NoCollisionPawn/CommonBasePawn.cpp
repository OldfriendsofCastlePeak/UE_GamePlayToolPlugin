﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CommonBasePawn.h"
#include "EnhancedInputComponent.h"
#include "CommonGamePlayToolPlugin/CommonGamePlayToolPlugin.h"
#include "Curves/CurveFloat.h"
#include "CommonGamePlayToolPlugin/Component/Input/InputBaseComponent.h"
#include "Curves/CurveVector.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"

// Sets default values
ACommonBasePawn::ACommonBasePawn(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//将Scene设置为根组件
	Scene=CreateDefaultSubobject<USceneComponent>("Scene");
	SetRootComponent(Scene);

	//弹簧臂组件挂到Scene上.
	SpringArm=CreateDefaultSubobject<USpringArmComponent>("SpringArm");
	SpringArm->SetupAttachment(Scene);

	//创建挂在弹簧臂上的相机,用于鸟瞰形式的移动.
	SpringArmCamera=CreateDefaultSubobject<UCameraComponent>("SpringArm_Camera");
	SpringArmCamera->SetupAttachment(SpringArm);

	//创建用于第一人称的弹簧臂组件,弹簧臂的长度应始终为0
	NormalCameraSpringArm=CreateDefaultSubobject<USpringArmComponent>(TEXT("NormalSpringArm"));
	NormalCameraSpringArm->SetupAttachment(RootComponent);
	NormalCameraSpringArm->TargetArmLength=0.0f;
	//创建用于第一人称世界形式的移动的相机.
	NormalCamera=CreateDefaultSubobject<UCameraComponent>("Normal_Camera");
	NormalCamera->SetupAttachment(NormalCameraSpringArm);

	//创建用于缩放形式移动和旋转的弹簧臂组件
	//ZoomSpringArm=CreateDefaultSubobject<USpringArmComponent>("ZoomSpringArm");
	//ZoomSpringArm->SetupAttachment(Scene);
	//创建用于缩放形式移动和旋转的相机
	//ZoomCamera=CreateDefaultSubobject<UCameraComponent>("ZoomCamera");
	//ZoomCamera->SetupAttachment(ZoomSpringArm);
}

// Called when the game starts or when spawned
void ACommonBasePawn::BeginPlay()
{
	Super::BeginPlay();
	if (SpringArmCamera->IsActive()&&NormalCamera->IsActive())
	{
		UE_LOG(FCommonGamePlayLog,Warning,TEXT("SpringArm_Camera和Normal_Camera都处于激活状态,默认处理将SpringArm_Camera激活打开,其他相机关闭"));
		bSpringArmCameraFirstFrameMove=1;
		SpringArmCamera->SetActive(true);
		NormalCamera->SetActive(false);
	}
}

// Called every frame
void ACommonBasePawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	AutoRoundPointRotateEvent();
}

// Called to bind functionality to input
void ACommonBasePawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	//执行输入注册
	Execute_RegisterInputEvent(this);
	
	SetupPlayerInputComponentInternalEvent();
}

int32 ACommonBasePawn::GetAllInput()
{
	UEnhancedInputComponent*  EnhancedInputComponent=(Cast<UEnhancedInputComponent>(this->InputComponent));
	auto AA= &EnhancedInputComponent->GetActionEventBindings();
	for (int i=0;i<AA->Num();i++)
	{
		
		GEngine->AddOnScreenDebugMessage(-1,0.f,FColor::White,EnhancedInputComponent->GetActionEventBindings()[i].Get()->GetAction()->GetName());
	}
	return  Cast<UEnhancedInputComponent>(this->InputComponent)->GetActionEventBindings().Num();
}


#pragma region 移动方式切换

void ACommonBasePawn::InitializeMoveType(const EMoveWayType Value)
{
	return;
	//一开始没有设置移动方式,所以一开始不需要处理
	// switch (Value)
	// {
	// case EMoveWayType::BirdView:
	// 	
	// 	CurrentMoveWayType=EMoveWayType::BirdView;
	// 	break;
	// case EMoveWayType::FirstView:
	// 	
	// 	CurrentMoveWayType=EMoveWayType::FirstView;
	// 	break;
	//
	// case EMoveWayType::ZoomView:
	//
	// 	CurrentMoveWayType=EMoveWayType::ZoomView;
	// 	break;
	//
	// default:
	// 	CurrentMoveWayType=EMoveWayType::None;
	// 	break;
	// }
}

void ACommonBasePawn::SwitchMoveType(const EMoveWayType Value)
{
	
}
#pragma endregion

#pragma region IRegisterInputInterface接口

void ACommonBasePawn::RegisterInputEvent_Implementation()
{
	//遍历查找当前Pawn上的UInputBaseComponent,再调用一次注册,防止调用OnPossess之后Pawn的输入映射清空的问题
	TArray<UInputBaseComponent*> InputBaseComponentArray;
	this->GetComponents(InputBaseComponentArray);
	for (UInputBaseComponent* InputBaseComponent:InputBaseComponentArray)
	{
		if (InputBaseComponent->bAuto_Register_Input_Mapping) Execute_RegisterInputEvent(InputBaseComponent);
	}
}

#pragma endregion

#pragma region IReceiveInputInterface接口

void ACommonBasePawn::ReceiveInputEvent_Implementation(const FVector2D& Value)
{
	//根据移动方式选择性做特定的处理:仅移动不旋转
	if (bMove_Action_Type==true&&bRotate_Action_Type==false)
	{
		Execute_ReceiveInputMoveEvent(this,Value);
		return;
	}
    
    //根据移动方式选择性做特定的处理:仅旋转不移动
    if (bMove_Action_Type==false&&bRotate_Action_Type==true)
    {
    	Execute_ReceiveInputRotateEvent(this,Value);
    	return;
    }
    
    //根据移动方式选择性做特定的处理:仅不旋转也不移动
    if (bMove_Action_Type==false&&bRotate_Action_Type==false)
    {
    	return;
    }
    
    //根据移动方式选择性做特定的处理:旋转加移动
    if (bMove_Action_Type==true&&bRotate_Action_Type==true)
    {
    	return;
    }
}

void ACommonBasePawn::ReceiveInputRotateEvent_Implementation(const FVector2D& Value)
{
	//根据激活的相机做特定的处理:Normal_Camera相机激活,SpringArm_Camera相机未激活
	if (NormalCamera->IsActive()&&!SpringArmCamera->IsActive())
	{
		//执行Normal_Camera相机的移动
		NormalCameraRotateEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:SpringArm_Camera相机激活,Normal_Camera相机未激活
	if (SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		//执行SpringArm_Camera相机的旋转
		SpringArmCameraRotateEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:Normal_Camera相机未激活,SpringArm_Camera相机未激活
	if (!SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		NoCameraRotateEvent(Value);
		return;
	}

	//根据激活的相机做特定的处理:Normal_Camera相机和SpringArm_Camera相机都激活时
	if (SpringArmCamera->IsActive()&&NormalCamera->IsActive())
	{
		AllCameraRotateEvent(Value);
		return;
	}
}

void ACommonBasePawn::ReceiveInputMoveEvent_Implementation(const FVector2D& Value)
{
	//根据激活的相机做特定的处理:Normal_Camera相机激活,SpringArm_Camera相机未激活
	if (NormalCamera->IsActive()&&!SpringArmCamera->IsActive())
	{
		//执行Normal_Camera相机的移动
		NormalCameraMoveEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:SpringArm_Camera相机激活,Normal_Camera相机未激活
	if (SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		//执行SpringArm_Camera相机的移动
		SpringArmCameraMoveEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:Normal_Camera相机未激活,SpringArm_Camera相机未激活
	if (!SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		NoCameraMoveEvent(Value);
		return;
	}

	//根据激活的相机做特定的处理:Normal_Camera相机和SpringArm_Camera相机都激活时
	if (SpringArmCamera->IsActive()&&NormalCamera->IsActive())
	{
		AllCameraMoveEvent(Value);
		return;
	}
}

void ACommonBasePawn::ReceiveInputViewZoomEvent_Implementation(const float Value)
{
	//根据激活的相机做特定的处理:Normal_Camera相机激活,SpringArm_Camera相机未激活
	if (NormalCamera->IsActive()&&!SpringArmCamera->IsActive())
	{
		//执行Normal_Camera相机的移动
		NormalCameraViewScaleEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:SpringArm_Camera相机激活,Normal_Camera相机未激活
	if (SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		//执行SpringArm_Camera相机的移动
		SpringArmCameraViewScaleEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:Normal_Camera相机未激活,SpringArm_Camera相机未激活
	if (!SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		NoCameraViewScaleEvent(Value);
		return;
	}

	//根据激活的相机做特定的处理:Normal_Camera相机和SpringArm_Camera相机都激活时
	if (SpringArmCamera->IsActive()&&NormalCamera->IsActive())
	{
		AllCameraViewScaleEvent(Value);
		return;
	}
}



#pragma endregion

#pragma region 移动
//获取SpringArmCamera移动速度
FVector2D ACommonBasePawn::GetSpringArmCameraMoveSpeed(const float Value) const
{
	if (SpringArmCameraMoveSpeedCurve)
	{
		const FVector CurveValue= SpringArmCameraMoveSpeedCurve->GetVectorValue(Value);
		return FVector2D(CurveValue.X*SpringArmCameraMoveParam.X,CurveValue.Y*SpringArmCameraMoveParam.Y);
	}
	return FVector2D::One();
}

//NormalCamera移动
void ACommonBasePawn::NormalCameraMoveEvent_Implementation(const FVector2D& Value)
{
	//不允许在视角过渡时移动、当bCan_Move为false时退出、播放Sequence时不准许移动
	if (!bCanMove||bPlayingViewBlend||bPlayingSequence) return;
	
	//在Normal Camera移动移动中监测角度是否满足装换到SpringArm Camera
	if (UKismetMathLibrary::InRange_FloatFloat(
			GetPlayerCameraManager()->GetCameraRotation().Pitch,
			SpringArmCameraConvertPitchRotateRange.X,
			SpringArmCameraConvertPitchRotateRange.Y,
			true,
			true))
	{
		//角度在范围内,可以从Normal_Camera转为SpringArm_Camera
		NormalCameraToSpringArmCamera();
		
		//重置自动旋转时间
		ResetAutoRotateTotalTime();
		return;
	}
	
	//开启NormalCameraSpringArm弹簧臂的移动Lag,使其移动更加平滑
	if (!NormalCameraSpringArm->bEnableCameraLag) NormalCameraSpringArm->bEnableCameraLag=1;
	
	//根据弹簧臂长度计算移动的值
	const float MoveValue=this->SpringArm->TargetArmLength*(0.005)>=10?this->SpringArm->TargetArmLength*(0.005):10;

	//获取当前的视角角度
	const FRotator CurrentViewRotate = GetPlayerCameraManager()->GetCameraRotation();

	//计算在X方向上的移动距离.
	const FVector XVectorNormal=UKismetMathLibrary::Normal(UKismetMathLibrary::GetRightVector(FRotator(
		0,
		CurrentViewRotate.Yaw,
		CurrentViewRotate.Roll)));
	const FVector XMoveVector=XVectorNormal*(MoveValue*Value.X*NormalCameraMoveSpeed.X);
	
	//计算在Y方向上的移动距离.
	const FVector YVectorNormal=UKismetMathLibrary::Normal(UKismetMathLibrary::GetForwardVector(FRotator(
		0,
		CurrentViewRotate.Yaw,
		CurrentViewRotate.Roll)));
	const FVector YMoveVector=YVectorNormal*(MoveValue*Value.Y*NormalCameraMoveSpeed.Y);

	//计算Pawn的最终位置
	const FVector PawnFinalLocation=GetActorLocation()+XMoveVector+YMoveVector;

	//确保Actor的角度的0
	SetActorRotation(FRotator::ZeroRotator);
	
	//更新Pawn的位置.
	if (bCanLimitMoveRange)
	{
		//限定角度
		SetActorLocation(LimitInRectRange(PawnFinalLocation,XMoveRange,YMoveRange,MoveOffsetAngle));
	}
	else
	{
		SetActorLocation(PawnFinalLocation);
	}
}

//SpringArmCamera移动
void ACommonBasePawn::SpringArmCameraMoveEvent_Implementation(const FVector2D& Value)
{
	//不允许在视角过度中移动、和bCanMove为false时移动
	if (!bCanMove||bPlayingViewBlend) return;

	//在除第一次的移动之外,其他时候需要开启弹簧臂的bEnableCameraLag
	if (!bSpringArmCameraFirstFrameMove)
	{
		//在最后开启弹簧臂的bEnableCameraLag,防止移动的第一帧的不平滑
		if (!SpringArm->bEnableCameraLag) SpringArm->bEnableCameraLag=1;
	}
	
	//根据弹簧臂长度计算移动的值
	//const float MoveValue=SpringArm->TargetArmLength*(0.008)>=10?this->SpringArm->TargetArmLength*(0.008):10;
	const FVector2D MoveValue=GetSpringArmCameraMoveSpeed(SpringArm->TargetArmLength);
	
	//获取当前相机的角度
	const FRotator CurrentCameraView=GetPlayerCameraManager()->GetCameraRotation();
	
	//计算在X方向上的移动距离.
	const FVector XVectorNormal=UKismetMathLibrary::Normal(UKismetMathLibrary::GetRightVector(FRotator(
		0,
		CurrentCameraView.Yaw,
		CurrentCameraView.Roll)));
	const FVector XMoveVector=XVectorNormal*(MoveValue.X*Value.X);
	
	//计算在Y方向上的移动距离.
	const FVector YVectorNormal=UKismetMathLibrary::Normal(UKismetMathLibrary::GetForwardVector(FRotator(
		0,
		CurrentCameraView.Yaw,
		CurrentCameraView.Roll)));
	const FVector YMoveVector=YVectorNormal*(MoveValue.Y*Value.Y);

	//计算Pawn的最终位置
	const FVector PawnFinalLocation=GetActorLocation()+XMoveVector+YMoveVector;

	//确保Actor的角度的0
	SetActorRotation(FRotator::ZeroRotator);
	
	//更新Pawn的位置.
	if (bCanLimitMoveRange)
	{
		//限定角度
		SetActorLocation(LimitInRectRange(PawnFinalLocation,XMoveRange,YMoveRange,MoveOffsetAngle));
	}
	else
	{
		SetActorLocation(PawnFinalLocation);
	}

	//在第一次运行完之后,将其改为false
	if (bSpringArmCameraFirstFrameMove) bSpringArmCameraFirstFrameMove=0;
	
}

//没有相机激活时的移动事件
void ACommonBasePawn::NoCameraMoveEvent_Implementation(const FVector2D& Value)
{
	UE_LOG(LogTemp,Warning,TEXT("Erro：Pawn上没有激活的Camera"));
}

//相机都激活时的移动事件
void ACommonBasePawn::AllCameraMoveEvent_Implementation(const FVector2D& Value)
{
	GEngine->AddOnScreenDebugMessage(-1,3.f,FColor::White,TEXT("Erro：Pawn的Camera都已激活,这将出现逻辑错误"));
	UE_LOG(LogTemp,Warning,TEXT("Erro：Pawn的Camera都已激活,这将出现逻辑错误"));
}

#pragma endregion

#pragma region 旋转
//NormalCamera旋转
void ACommonBasePawn::NormalCameraRotateEvent_Implementation(const FVector2D& Value)
{
	//不允许在视角过度中转动视角
	if (bPlayingViewBlend||!bCanRotate) return;
	
	//开启NormalCameraSpringArm弹簧臂的旋转Lag,使其旋转更加平滑
	if (!NormalCameraSpringArm->bEnableCameraRotationLag) NormalCameraSpringArm->bEnableCameraRotationLag=1;

	//获取当前相机的角度
	const FRotator CurrentCameraRotation=GetPlayerCameraManager()->GetCameraRotation();
	
	//计算旋转的Y:Pitch值,限定Pitch的角度,因为Pitch的值为-90或90度时会有问题.
	const float NewPitchValue=Value.Y*NormalCameraRotateSpeed.Y*GetWorld()->GetDeltaSeconds()+CurrentCameraRotation.Pitch;
	//const float NewPitchValue=;;
	
	//计算旋转的Z:Yaw值
	const float NewYawValue=Value.X*NormalCameraRotateSpeed.X*GetWorld()->GetDeltaSeconds()+CurrentCameraRotation.Yaw;

	//更新弹簧臂的角度
	if (bCanLimitRotate)
	{
		SetSpringArmRotation(FRotator(
			UKismetMathLibrary::FClamp(NewPitchValue,NormalCameraPitchRotateRange.X,NormalCameraPitchRotateRange.Y),
			UKismetMathLibrary::FClamp(NewYawValue,YawRotateRange.X,YawRotateRange.Y),
			UKismetMathLibrary::FClamp(CurrentCameraRotation.Roll,RollRotateRange.X,RollRotateRange.Y)));
	}
	else
	{
		SetSpringArmRotation(FRotator(NewPitchValue,NewYawValue,CurrentCameraRotation.Roll));
	}
	
}

//SpringArmCamera旋转
void ACommonBasePawn::SpringArmCameraRotateEvent_Implementation(const FVector2D& Value)
{
	//不允许在视角过度中转动视角
	if (!bCanRotate||bPlayingViewBlend) return;
	
	//检测bEnableCameraRotationLag是否开启
	if (!SpringArm->bEnableCameraRotationLag) SpringArm->bEnableCameraRotationLag=1;
	
	//计算旋转的Y:Pitch值
	const float NewPitchValue=Value.Y*SpringArmCameraRotateSpeed.Y+GetPlayerCameraManager()->GetCameraRotation().Pitch;

	//计算旋转的Z:Yaw值
	const float NewYawValue=Value.X*SpringArmCameraRotateSpeed.X+SpringArm->GetComponentRotation().Yaw;

	if (bCanLimitRotate)
	{
		SetSpringArmRotation(FRotator(
		UKismetMathLibrary::FClamp(NewPitchValue,SpringArmCameraPitchRotateRange.X,SpringArmCameraPitchRotateRange.Y),
		UKismetMathLibrary::FClamp(NewYawValue,YawRotateRange.X,YawRotateRange.Y),
		UKismetMathLibrary::FClamp(GetPlayerCameraManager()->GetCameraRotation().Roll,RollRotateRange.X,RollRotateRange.Y)
			));
	}
	else
	{
		SetSpringArmRotation(FRotator(NewPitchValue,NewYawValue,GetPlayerCameraManager()->GetCameraRotation().Roll));
	}
}

//无相机旋转事件
void ACommonBasePawn::NoCameraRotateEvent_Implementation(const FVector2D& Value)
{
}

//所有相机旋转事件
void ACommonBasePawn::AllCameraRotateEvent_Implementation(const FVector2D& Value)
{
}

//设置角度
void ACommonBasePawn::SetSpringArmRotation(const FRotator& Rotation)
{
	SetActorRotation(FRotator::ZeroRotator);
	SpringArm->SetWorldRotation(Rotation);
	NormalCameraSpringArm->SetWorldRotation(Rotation);
}

//获取角度
FRotator ACommonBasePawn::GetSpringArmRotation()
{
	if (NormalCamera->GetComponentRotation()!=SpringArmCamera->GetComponentRotation())
	{
		//强制使用NormalCamera的Rotation
		UE_LOG(FCommonGamePlayLog,Warning,TEXT("相机的角度不一致,使用NormalCamera的角度"));
		SpringArmCamera->GetComponentRotation()=NormalCamera->GetComponentRotation();
	}
	return NormalCamera->GetComponentRotation();
}
#pragma endregion

#pragma region 视野FOV
void ACommonBasePawn::SetCameraFOV(const float Value)
{
	NormalCamera->FieldOfView=Value;
	SpringArmCamera->FieldOfView=Value;
}

float ACommonBasePawn::GetCameraFOV()
{
	if (NormalCamera->FieldOfView!=SpringArmCamera->FieldOfView)
	{
		//强制使用NormalCamera的FOV
		UE_LOG(FCommonGamePlayLog,Warning,TEXT("相机的FOV不一致,使用NormalCamera的FOV"));
		SpringArmCamera->FieldOfView=NormalCamera->FieldOfView;
	}
	return NormalCamera->FieldOfView;
}

void ACommonBasePawn::ResetCameraFOV()
{
	NormalCamera->FieldOfView=90.f;
	SpringArmCamera->FieldOfView=90.f;
}
#pragma endregion

#pragma region 相机纵横比例
void ACommonBasePawn::SetCameraAspectRatio(const float Value)
{
	if (!NormalCamera->bConstrainAspectRatio) NormalCamera->bConstrainAspectRatio=1;
	if (!SpringArmCamera->bConstrainAspectRatio) SpringArmCamera->bConstrainAspectRatio=1;
	NormalCamera->AspectRatio=Value;
	SpringArmCamera->AspectRatio=Value;
}

void ACommonBasePawn::CloseCameraAspectRatio()
{
	NormalCamera->bConstrainAspectRatio=false;
	SpringArmCamera->bConstrainAspectRatio=false;
}


#pragma endregion

#pragma region 缩放

//获取视角缩放的TimeLine
UTimelineComponent* ACommonBasePawn::GetViewScaleTimeLine()
{
	if (ViewScaleTimeLine!=nullptr) return ViewScaleTimeLine;

	ViewScaleTimeLine=NewObject<UTimelineComponent>(this,TEXT("ViewScaleTimeLine"));
	ViewScaleTimeLine->RegisterComponent();
	ViewScaleTimeLine->SetTimelineLengthMode(ETimelineLengthMode::TL_TimelineLength);
	ViewScaleTimeLine->SetLooping(false);
	ViewScaleTimeLine->SetTimelineLength(0.25f);
	
	//定义一个FOnTimelineEvent委托,用来绑定更新事件.
	FOnTimelineFloat OnTimelineEvent;
	OnTimelineEvent.BindUFunction (this,"CameraViewScaleUpdateEvent");
	UCurveFloat* CurveFloat=NewObject<UCurveFloat>();
	const FKeyHandle StartKey=CurveFloat->FloatCurve.UpdateOrAddKey(0,0);
	const FKeyHandle EndtKey=CurveFloat->FloatCurve.UpdateOrAddKey(0.25,1);
	CurveFloat->FloatCurve.SetKeyTangentMode(StartKey,ERichCurveTangentMode::RCTM_User,false);
	CurveFloat->FloatCurve.SetKeyTangentMode(EndtKey,ERichCurveTangentMode::RCTM_User,false);
	ViewScaleTimeLine->AddInterpFloat(CurveFloat,OnTimelineEvent);

	return ViewScaleTimeLine;
}

//总的视野缩放更新事件
void ACommonBasePawn::CameraViewScaleUpdateEvent(const float Value)
{
	//根据激活的相机做特定的处理:Normal_Camera相机激活,SpringArm_Camera相机未激活
	if (NormalCamera->IsActive()&&!SpringArmCamera->IsActive())
	{
		//执行Normal_Camera相机的移动
		NormalCameraCameraViewScaleUpdateEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:SpringArm_Camera相机激活,Normal_Camera相机未激活
	if (SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		//执行SpringArm_Camera相机的旋转
		SpringArmCameraViewScaleUpdateEvent(Value);
		return;
	}
    
	//根据激活的相机做特定的处理:Normal_Camera相机未激活,SpringArm_Camera相机未激活
	if (!SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		NoCameraCameraViewScaleUpdateEvent(Value);
		return;
	}

	//根据激活的相机做特定的处理:Normal_Camera相机和SpringArm_Camera相机都激活时
	if (SpringArmCamera->IsActive()&&NormalCamera->IsActive())
	{
		AllCameraCameraViewScaleUpdateEvent(Value);
		return;
	}
}

//NormalCamera缩放
void ACommonBasePawn::NormalCameraViewScaleEvent_Implementation(const float& Value)
{
	//检测是否可拉近拉远视角、当前正在播放漫游Sequence动画时退出、当前正在进行视口混合时退出
	if (!bCanViewScale||bPlayingSequence||bPlayingViewBlend) return;
	
	//尝试转换为SpringArmCamera
	if (bCanAutoConvertSpringArmCamera)
	{
		//检测当前角度是否在限定范围内,在此范围内才考虑切换相机
		if (GetPlayerCameraManager()->GetCameraRotation().Pitch>=SpringArmCameraConvertPitchRotateRange.X&&
			GetPlayerCameraManager()->GetCameraRotation().Pitch<=SpringArmCameraConvertPitchRotateRange.Y)
		{
			NormalCameraToSpringArmCamera();
			return;
		}
	}

	if (bNormalCameraCanViewScale)
	{
		//获取玩家控制器
		if (APlayerController* PC=Cast<APlayerController>(GetController()))
		{
			//如果当前正在播放,则停止
			if (GetViewScaleTimeLine()->IsPlaying())
			{
				GetViewScaleTimeLine()->Stop();
			}
		
			FVector2D MousePosition;
			PC->GetMousePosition(MousePosition.X,MousePosition.Y);

			FVector WorldPosition,WorldDirection;
		
			ULocalPlayer* const LP = PC ? PC->GetLocalPlayer() : nullptr;
			if (LP && LP->ViewportClient)
			{
				FSceneViewProjectionData ProjectionData;
				if (LP->GetProjectionData(LP->ViewportClient->Viewport,ProjectionData))
				{
					FMatrix const InvViewProjMatrix = ProjectionData.ComputeViewProjectionMatrix().InverseFast();
					FSceneView::DeprojectScreenToWorld(MousePosition, ProjectionData.GetConstrainedViewRect(), InvViewProjMatrix, /*out*/ WorldPosition, /*out*/ WorldDirection);
				}
			}
			else
			{
				return;
			}

		
		
			StartLocation=WorldPosition;
			TargetLocation=StartLocation+WorldDirection*Value*NormalCameraViewScaleSpeed;
			//是否启用障碍物阻挡
			if (bNormalCameraViewScaleBarrierBlock)
			{
				TArray<AActor*>IgnoreActors;
				FHitResult HitResult;
				UKismetSystemLibrary::LineTraceSingle(
					this,
					StartLocation,
					TargetLocation,
					TraceTypeQuery1,
					false,
					IgnoreActors,
					EDrawDebugTrace::ForDuration,
					HitResult,
					true,FLinearColor::Red,FLinearColor::Green,100.f);

				if (HitResult.bBlockingHit)
				{
					TargetLocation=StartLocation+WorldDirection*Value*(HitResult.Distance-100.f);
				}
			}
			//重置自动旋转时间
			ResetAutoRotateTotalTime();
        
			//播放TimeLine
			GetViewScaleTimeLine()->PlayFromStart();
		}
	}
	
	
}

//SpringArmCamera缩放
void ACommonBasePawn::SpringArmCameraViewScaleEvent_Implementation(const float& Value)
{
	//检测是否可拉近拉远视角、当前正在播放漫游Sequence动画时退出、当前正在进行视口混合时退出
	if (!bCanViewScale||bPlayingSequence||bPlayingViewBlend) return;

	//检测当前是否激活了SpringArm_Camera
	if (!SpringArmCamera->IsActive())
	{
		UE_LOG(FCommonGamePlayLog,Warning,TEXT("SpringArmCamera相机当前未激活,无法缩放视角"));
		return;
	}

	//检查Normal_Camera是否为激活,Normal_Camera此时不应该为激活状态
	if (NormalCamera->IsActive())
	{
		GEngine->AddOnScreenDebugMessage(-1,3.f,FColor::White,TEXT("Erro:Normal_Camera是激活的"));
		NormalCamera->SetActive(false);
	}
	
	//弹簧臂的变化值
	const float SpringArmChange_Value=GetSpringArmeCameraViewScaleSpeed(SpringArm->TargetArmLength)*Value;
	GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::White,FString::Printf(TEXT("GetSpringArmeCameraViewScaleSpeed的值为%f"),SpringArmChange_Value));
	
	//当前的弹簧臂的值
	CurrentSpringArm_Length=SpringArm->TargetArmLength;
	
	//目标的弹簧臂长度
	if (bCanLimitViewScale)
	{
		TargetSpringArm_Length=UKismetMathLibrary::FClamp(
			SpringArm->TargetArmLength-SpringArmChange_Value,
			SpringArmCameraSpringArmLengthRange.X,
			SpringArmCameraSpringArmLengthRange.Y);
	}
	else
	{
		//只限制最小值0
		TargetSpringArm_Length=(SpringArm->TargetArmLength-SpringArmChange_Value)>0?SpringArm->TargetArmLength-SpringArmChange_Value:0;
	}
	
	//重置自动旋转时间
	ResetAutoRotateTotalTime();

	//播放TimeLine
	GetViewScaleTimeLine()->PlayFromStart();
}

//无相机缩放事件
void ACommonBasePawn::NoCameraViewScaleEvent_Implementation(const float& Value)
{
	GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::White,TEXT("NoCamera ViewScale 功能待完善"));
}

//所有相机缩放事件
void ACommonBasePawn::AllCameraViewScaleEvent_Implementation(const float& Value)
{
	GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::White,TEXT("AllCamera ViewScale 功能待完善"));
}

//NormalCamera视口缩放更新事件
void ACommonBasePawn::NormalCameraCameraViewScaleUpdateEvent_Implementation(const float Value)
{
	SetActorLocation(UKismetMathLibrary::VLerp(StartLocation,TargetLocation,Value));
}

//SpringArmCamera视口缩放更新事件
void ACommonBasePawn::SpringArmCameraViewScaleUpdateEvent_Implementation(const float Value)
{
	const float SpringArm_Final_Length= UKismetMathLibrary::Lerp(CurrentSpringArm_Length,TargetSpringArm_Length,Value);
	SpringArm->TargetArmLength=SpringArm_Final_Length;
}

//无相机视口缩放更新事件
void ACommonBasePawn::NoCameraCameraViewScaleUpdateEvent_Implementation(const float Value)
{
}

//所有相机视口缩放更新事件
void ACommonBasePawn::AllCameraCameraViewScaleUpdateEvent_Implementation(const float Value)
{
}

//SpringArmeCamera获取视口缩放的速度
float ACommonBasePawn::GetSpringArmeCameraViewScaleSpeed(const float Value)
{
	if (SpringArmCameraViewScaleSpeedCurve) return SpringArmCameraViewScaleSpeedCurve->GetFloatValue(Value)*CameraViewScaleParam;
	return 10.f;
}
#pragma endregion	

#pragma region 自动旋转
//
void ACommonBasePawn::AutoRoundPointRotateEvent_Implementation()
{
	//检测是否开启自动旋转、检测当前是否正在播放漫游动画、检测当前是否正在进行视角混合
	if (!bCanAutoRotate||bPlayingSequence||bPlayingViewBlend)
	{
		CurrentNoActionTime=0.f;
		return;
	}
	
	//监测未操作时间是否大于设定值
	if (CurrentNoActionTime<StartAutoRotateTime)
	{
		CurrentNoActionTime+=UGameplayStatics::GetWorldDeltaSeconds(this);
		return;
	}

	//检测当前使用的相机是否为SpringArm_Camera
	if (!SpringArmCamera->IsActive())
	{
		//当前没有激活SpringArm_Camera则需要转换
		if (NormalCamera->IsActive())
		{
			NormalCameraToSpringArmCamera();
		}
		return;
	}
	
	//每帧的转动速度
	const float PerTick_Auto_Rotate_Speed=AutoRotateSpeed*GetWorld()->GetDeltaSeconds();

	//旋转,更新角度
	SpringArmCameraRotateEvent(FVector2D(PerTick_Auto_Rotate_Speed,0));
}

//
void ACommonBasePawn:: SpringArm_Camera_Round_Point_Rotate_Event_Implementation(const FVector Location,const FRotator Rotate,const float ViewDistance)
{
	//设置SpringArm的属性
	ForceConvertToSpingArmCameraSetProperty(Location,Rotate,ViewDistance);

	//设置累计未收到输入的时间 等于 开始自动旋转的时间
	CurrentNoActionTime=StartAutoRotateTime;

	//开启绕点旋转
	bCanAutoRotate=true;
}

//重置自动旋转的累计计时
void ACommonBasePawn::ResetAutoRotateTotalTime_Implementation()
{
	CurrentNoActionTime=0.f;
}


#pragma endregion

#pragma region 输入事件输入相关


#pragma endregion

void ACommonBasePawn::GetCurrentActiveCamera(
	TEnumAsByte<ECurrentActiveCamera>& CurrentActiveCamera)
{
	//Normal_Camera相机和SpringArm_Camera相机都激活时
	if (SpringArmCamera->IsActive()&&NormalCamera->IsActive())
	{
		CurrentActiveCamera=ECurrentActiveCamera::All_Camera_Active;
		return;
	}
	
	//当Normal_Camera相机激活,且SpringArm_Camera相机未激活时调用
	if (NormalCamera->IsActive()&&!SpringArmCamera->IsActive())
	{
		CurrentActiveCamera=ECurrentActiveCamera::Only_Normal_Camera_Active;
		return;
	}

	//当SpringArm_Camera相机激活,且Normal_Camera相机未激活时调用
	if (SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		CurrentActiveCamera=ECurrentActiveCamera::Only_SpringArm_Camera_Active;
		return;
	}

	//Normal_Camera相机和SpringArm_Camera相机都未激活时
	if (!SpringArmCamera->IsActive()&&!NormalCamera->IsActive())
	{
		CurrentActiveCamera=ECurrentActiveCamera::No_Camera_Active;
	}
}

void ACommonBasePawn::Ensure_Only_One_Camera_Active_Internal()
{
	if (SpringArmCamera->IsActive()&&NormalCamera->IsActive())
	{
		if (NormalCamera->IsActive())
		{
			//两个相机都激活,优先激活SpringArm_Camera
			NormalCamera->SetActive(false);
		}
	}
	else
	{
		if (!NormalCamera->IsActive())
		{
			//两个相机都为激活,优先激活SpringArm_Camera
			SpringArmCamera->SetActive(true);
		}
	}
}

void ACommonBasePawn::OnOnlyMouseLeftButtonPressed_Internal(
	const FVector2D& Value)
{
	//仅当鼠标左键按下,且鼠标右键未按下时.
	if (bMove_Action_Type&&!bRotate_Action_Type)
	{
		OnOnlyMouseLeftButtonPressed_Internal(Value);
		return;
	}
	
	//仅当鼠标右键按下,且鼠标左键未按下时.
	if (bRotate_Action_Type&&!bMove_Action_Type)
	{
		OnOnlyMouseRightButtonPressed_Internal(Value);
		return;
	}
	
	//当鼠标左键与右键都按下时调用
	if (bMove_Action_Type&&bRotate_Action_Type)
	{
		OnMouseAllButtonPressed_Internal(Value);
	}
}

void ACommonBasePawn::OnOnlyMouseRightButtonPressed_Internal(
const FVector2D& Value)
{
	//仅当鼠标左键按下,且鼠标右键未按下时.
	if (bMove_Action_Type&&!bRotate_Action_Type)
	{
		OnOnlyMouseLeftButtonPressed_Internal(Value);
		return;
	}
	
	//仅当鼠标右键按下,且鼠标左键未按下时.
	if (bRotate_Action_Type&&!bMove_Action_Type)
	{
		OnOnlyMouseRightButtonPressed_Internal(Value);
		return;
	}
	
	//当鼠标左键与右键都按下时调用
	if (bMove_Action_Type&&bRotate_Action_Type)
	{
		OnMouseAllButtonPressed_Internal(Value);
	}
}

void ACommonBasePawn::OnMouseAllButtonPressed_Internal(
	const FVector2D& Value)
{
	//仅当鼠标左键按下,且鼠标右键未按下时.
	if (bMove_Action_Type&&!bRotate_Action_Type)
	{
		OnOnlyMouseLeftButtonPressed_Internal(Value);
		return;
	}
	
	//仅当鼠标右键按下,且鼠标左键未按下时.
	if (bRotate_Action_Type&&!bMove_Action_Type)
	{
		OnOnlyMouseRightButtonPressed_Internal(Value);
		return;
	}
	
	//当鼠标左键与右键都按下时调用
	if (bMove_Action_Type&&bRotate_Action_Type)
	{
		OnMouseAllButtonPressed_Internal(Value);
	}
}

#pragma region 相机转换
bool ACommonBasePawn::Can_Normal_Camera_To_SpringArm_Camera_Pitch_Range()
{
	return (UKismetMathLibrary::InRange_FloatFloat(
		GetPlayerCameraManager()->GetCameraRotation().Pitch,
		SpringArmCameraConvertPitchRotateRange.X,
		SpringArmCameraConvertPitchRotateRange.Y,
		true,
		true));
}

void ACommonBasePawn::NormalCameraToSpringArmCamera_Implementation()
{
	//检测SpringArm_Camera相机当前是否激活
	if (SpringArmCamera->IsActive()) return;

	//获取当前的视角位置和方向
	const FRotator CurrentCameraRotate=GetPlayerCameraManager()->GetCameraRotation();
	const FVector CurrentCameraLoc=GetPlayerCameraManager()->GetCameraLocation();

	//检查当前角度的Pitch值，是否处于限定范围内
	if (CurrentCameraRotate.Pitch<SpringArmCameraConvertPitchRotateRange.X||
		CurrentCameraRotate.Pitch>SpringArmCameraConvertPitchRotateRange.Y)
	{
		//GEngine->AddOnScreenDebugMessage(-1,1.f,FColor::White,TEXT("Erro:Z轴位置错误,超出限定范围,无法切换相机"));
		UE_LOG(LogTemp,Warning,TEXT("Erro:Z轴位置错误,超出限定范围,无法切换相机"));
		return ;
	}
	
	//检查当前位置的Z轴高度，是否处于限定范围
	if (CurrentCameraLoc.Z<ZMoveRange.X)				
	{
		//GEngine->AddOnScreenDebugMessage(-1,1.f,FColor::White,TEXT("Erro:相机角度出现错误,超过限定范围,无法切换相机"));
		UE_LOG(LogTemp,Warning,TEXT("Erro:相机角度出现错误,超过限定范围,无法切换相机"))
		return ;
	}

	//计算最终Pawn的位置，并计算弹簧臂应该设定的长度
	const float Camera_Vertical_Value=CurrentCameraLoc.Z-ZMoveRange.X;							//相机的垂直方向长度
	const double DegreeValue=FMath::Abs(UKismetMathLibrary::DegSin(CurrentCameraRotate.Pitch));	//求垂直边于斜边的比例
	const float FinalSpringArmLength=Camera_Vertical_Value/DegreeValue;								//最终的斜边长度（弹簧臂长度）
	
	//更新设置弹簧臂的长度
	this->SpringArm->TargetArmLength=FinalSpringArmLength;

	//计算Pawn最终的位置
	const FVector ForwardVector=UKismetMathLibrary::Normal(UKismetMathLibrary::GetForwardVector(CurrentCameraRotate));
	const FVector FinalLocation=FinalSpringArmLength*ForwardVector+CurrentCameraLoc;
	
	//归零角度
	SetActorRotation(FRotator::ZeroRotator);
	
	//更新Pawn的位置
	SetActorLocation(FinalLocation);
	
	//切换完毕NormalCameraSpringArm的角度归零
	NormalCameraSpringArm->SetWorldRotation(CurrentCameraRotate);
	SpringArm->SetWorldRotation(CurrentCameraRotate);
	
	//位置都已计算完毕,开始切换相机.
	SpringArmCamera->SetActive(true);	//激活弹簧臂相机
	NormalCamera->SetActive(false);	//灭活普通相机
	bSpringArmCameraFirstFrameMove=1;
}

bool ACommonBasePawn::SpringArmCameraToNormalCamera_Implementation()
{
	//检查普通的相机是否激活
	if (NormalCamera->IsActive())	return true;
	
	//获取当前视角的位置和角度
	const FVector CurrentViewLocation=GetPlayerCameraManager()->GetCameraLocation();
	const FRotator CurrentViewRotate=GetPlayerCameraManager()->GetCameraRotation();

	//归零SpringArm的角度
	SetActorRotation(FRotator::ZeroRotator);

	//更新Actor的位置为视角的位置
	SetActorLocation(CurrentViewLocation);
	
	//设置弹簧臂的旋转为视角的旋转值
	SpringArm->SetWorldRotation(CurrentViewRotate);
	NormalCameraSpringArm->SetWorldRotation(CurrentViewRotate);
	
	//取消相机Lag和归零弹簧比的长度
	SpringArm->TargetArmLength=0;
	
	//切换相机
	NormalCamera->SetActive(true);
	SpringArmCamera->SetActive(false);
	
	return true;
}

void ACommonBasePawn::ForceConvertToSpringArmCamera_Implementation()
{
	//先检查当前的是否为SpringArm_Camera
	if (SpringArmCamera->IsActive()) return;
	
	//尝试使用方法转换
	NormalCameraToSpringArmCamera();

	//再检查当前的是否为SpringArm_Camera,如果还不是则直接转换
	if (!SpringArmCamera->IsActive())
	{
		SpringArmCamera->SetActive(true);	//激活弹簧臂相机
		NormalCamera->SetActive(false);	//灭活普通相机
		bSpringArmCameraFirstFrameMove=1;
	}
}

void ACommonBasePawn::ForceConvertToSpingArmCameraSetProperty_Implementation(
	const FVector Location,
	const FRotator Rotate,
	const float ViewDistance)
{
	//强制转换确保现在使用的是SpringArm_Camera
	ForceConvertToSpringArmCamera();

	//确保视口过渡的时候用于视口混合的TimeLine没有执行
    if (GetViewBlendTimeLine()!=nullptr&&GetViewBlendTimeLine()->IsPlaying())
    {
    	//有正在进行视口混合的的TimeLine正在执行,直接停止
    	GetViewBlendTimeLine()->Stop();
    	bPlayingViewBlend=false;
    }
	
	//设置弹簧臂的长度
	SpringArm->TargetArmLength=ViewDistance;

	//重置角度
	SetActorRotation(FRotator::ZeroRotator);
	
	//设置位置
	SetActorLocation(Location);

	//设置弹簧臂的角度
	SpringArm->SetWorldRotation(Rotate);
	NormalCameraSpringArm->SetWorldRotation(Rotate);
}

#pragma endregion

#pragma region 视口过渡
UTimelineComponent* ACommonBasePawn::GetViewBlendTimeLine()
{
	//确保用于视口混合的TimeLine有效
	if (!ViewBlendTimeLine)
	{
		//New一个TimeLine对象
		ViewBlendTimeLine=NewObject<UTimelineComponent>(this,TEXT("ViewBlendTimeLine"));

		//将组件注册到世界中,否则组件创建后功能无效
		ViewBlendTimeLine->RegisterComponent();
		
		ViewBlendTimeLine->SetTimelineLengthMode(ETimelineLengthMode::TL_TimelineLength);
		ViewBlendTimeLine->SetLooping(false);
		ViewBlendTimeLine->SetTimelineLength(1.f);

		//绑定TimeLine的更新事件
		FOnTimelineFloat OnTimelineEvent;
		OnTimelineEvent.BindUFunction(this,"ViewBlendTimeLineUpdateEvent");

		if (ViewBlendCueve)
		{
			ViewBlendTimeLine->AddInterpFloat(ViewBlendCueve,OnTimelineEvent);
		}
		else
		{
			//当没有设置的曲线时,将自定义创建一个曲线
			UCurveFloat* CurveFloat=NewObject<UCurveFloat>();
			CurveFloat->FloatCurve.UpdateOrAddKey(0,0);
			CurveFloat->FloatCurve.UpdateOrAddKey(1,1);
			ViewBlendTimeLine->AddInterpFloat(CurveFloat,OnTimelineEvent);
		}
		
		//绑定TimeLine的结束事件
		FOnTimelineEvent OnTimelineFinishedEvent;
		OnTimelineFinishedEvent.BindUFunction(this,"ViewBlendTimeLineEndEvent");
		ViewBlendTimeLine->SetTimelineFinishedFunc(OnTimelineFinishedEvent);
	}
	return  ViewBlendTimeLine;
}


void ACommonBasePawn::SetCameraView_Implementation(
	const FVector& InVector,
	const FRotator& InRotator,
	const FName ViewBlendTag)
{
	//确保使用直接设置位置和角度的时候用于视口混合的TimeLine没有执行,防止位置被TimeLine的更新委托重置覆盖
	if (bPlayingViewBlend&&GetViewBlendTimeLine()!=nullptr)
	{
		//有正在进行视口混合的的TimeLine正在执行,直接停止
		GetViewBlendTimeLine()->Stop();
		bPlayingViewBlend=false;
	}

	//取消位置和角度平滑过渡
	NormalCameraSpringArm->bEnableCameraLag=0;
	NormalCameraSpringArm->bEnableCameraRotationLag=0;
	SpringArm->bEnableCameraLag=0;
	SpringArm->bEnableCameraRotationLag=0;

	//确保当前Normal Camra激活,SpringArm Camera不激活
	if (!NormalCamera->IsActive()||
		SpringArmCamera->IsActive())
	{
		NormalCamera->SetActive(true);
		SpringArmCamera->SetActive(false);
		//UE_LOG(LogTemp,Warning,TEXT("激活NormalCamera相机"));
		//GEngine->AddOnScreenDebugMessage(-1,1.f,FColor::White,TEXT("激活NormalCamera相机"));
	}
	
	//更新位置
	SetActorLocation(InVector);
	
	SetSpringArmRotation(InRotator);
	
	//更新记录视角混合的标识符
	LastViewBlendTag=ViewBlendTag;
}

void ACommonBasePawn::ViewBlendTimeLinePlay_Implementation(
	const FVector& InVector,
	const FRotator& InRotator,
	const float BlendTime,
	const FName ViewBlendTag)
{
	//过渡时间为0表示位置直接切换
	if (BlendTime==0)
	{
		//直接设置Camera的视角位置
		SetCameraView(InVector,InRotator,ViewBlendTag);

		//调用通知以便在蓝图中扩展操作
		ViewBlendTimeLineEndEvent();
		return;
	}
	
	//取消位置和角度平滑过渡
	NormalCameraSpringArm->bEnableCameraLag=0;
	NormalCameraSpringArm->bEnableCameraRotationLag=0;
	SpringArm->bEnableCameraLag=0;
	SpringArm->bEnableCameraRotationLag=0;
	
	

	//设置播放速率
	GetViewBlendTimeLine()->SetPlayRate(1/BlendTime);
	
	//获取当前视角的位置和角度
	StartLocation=GetPlayerCameraManager()->GetCameraLocation();
	StartRotate=GetPlayerCameraManager()->GetCameraRotation();
	
	//记录目标的位置和角度
	TargetLocation=InVector;
	TargetRotate=InRotator;

	//视角混合需要使用Normal_Camera
	if (!NormalCamera->IsActive())
	{
		SpringArmCameraToNormalCamera();
	}
	
	//用于定义当前处于视口混合状态
	bPlayingViewBlend=true;

	//重置自动旋转时间
	ResetAutoRotateTotalTime();
	
	//播放TimeLine
	GetViewBlendTimeLine()->PlayFromStart();

	//更新记录视角混合的标识符
	LastViewBlendTag=ViewBlendTag;
}

void ACommonBasePawn::ViewBlendTimeLineUpdateEvent_Implementation(
	const float Value)
{
	//更新位置
	SetActorLocation(UKismetMathLibrary::VLerp(StartLocation,TargetLocation,Value));
	
	//更新角度
	SetSpringArmRotation(FRotator(UKismetMathLibrary::RLerp(StartRotate,TargetRotate,Value,true)));
}

void ACommonBasePawn::ViewBlendTimeLineEndEvent_Implementation()
{
	//将bPlayingViewBlend设置为false表示不处于视口混合过程中
	if (bPlayingViewBlend) bPlayingViewBlend=false;
}

#pragma endregion

#pragma region 内部使用方法

APlayerCameraManager* ACommonBasePawn::GetPlayerCameraManager()
{
	if (Controller)
	{
		if (APlayerController* PC=Cast<APlayerController>(Controller))
		{
			return PC->PlayerCameraManager;
		}
	}
	check(false&&"ACommonBasePawn::GetPlayerCameraManager(): Controller is invalid");
	return nullptr;
}
#pragma endregion

#pragma region 限制移动范围
FVector ACommonBasePawn::LimitInCircleRange(const FVector& CurrentLocation,const FVector& CircleCenter,const float& Radius)
{
	//计算当前位置相对于圆心偏移的向量
	const FVector CicleOffsetVector=CurrentLocation-CircleCenter;

	//检查向量的长度是否超出半径
	if (CicleOffsetVector.Size()>Radius)
	{
		//超出范围,校准位置
		const FVector FinalLocation=CicleOffsetVector.GetSafeNormal(1.e-4f)*Radius+CircleCenter;
		return FVector(FinalLocation.X,FinalLocation.Y,CurrentLocation.Z);
	}else
	{
		//在范围内,不对当前位置进行修改
		return CurrentLocation;
	}
}

FVector ACommonBasePawn::LimitInRectRange(
	const FVector& CurrentLocation,
	const FVector2D& XRange,
	const FVector2D& YRange,
	const float& YawAngleOffset)
{
	//如果场景的YAW角度偏移为0,则简单限定后返回
	if (YawAngleOffset==0)
	{
		const FVector FinalLocation(
			UKismetMathLibrary::FClamp(CurrentLocation.X,XMoveRange.X,XMoveRange.Y),
			UKismetMathLibrary::FClamp(CurrentLocation.Y,YMoveRange.X,YMoveRange.Y),
			CurrentLocation.Z);
		
		return FinalLocation;
	}
	
	//获取X和Y的中心对称点
	const FVector CentrePoint(FVector((XRange.Y-XRange.X)/2,(YRange.Y-YRange.X)/2,CurrentLocation.Z));

	//下一步目的:将不标准位置转换为标准位置进行位置限制处理
	
	//获取中心点到当前位置的移动偏移向量
	FVector CurrentOffstVector=CurrentLocation-CentrePoint;

	//将移动偏移向量转换为标准的偏移向量
	FVector OffsetVector=FRotator(0,0,YawAngleOffset).RotateVector(CurrentOffstVector);

	//获取将当前位置转换为标准的位置
	FVector StandardCurrentLocation=CentrePoint+OffsetVector;

	//检测当前的标准位置的X值是否在范围内
	if (StandardCurrentLocation.X<XRange.X || StandardCurrentLocation.X>XRange.Y)
	{
		//X不处于处于范围
		
		//计算当前的比例X:Y
		const float CurrentScale=StandardCurrentLocation.X/StandardCurrentLocation.Y;
		
		//进一步确定,标准位置的X值小于限定的最小值
		if (StandardCurrentLocation.X<XRange.X)
		{
			//校准标准位置的X值为限定的最小值,同时等比例更改Y的值
			const float NewYValue=XRange.X/CurrentScale;
			StandardCurrentLocation=FVector(XRange.X,NewYValue,StandardCurrentLocation.Z);
		}
		
		//进一步确定,标准位置的X值大于限定的最大值
		if (StandardCurrentLocation.X>XRange.Y)
		{
			//校准标准位置的X值为限定的最小大值,同时等比例更改Y的值
			const float NewYValue=XRange.Y/CurrentScale;
			StandardCurrentLocation=FVector(XRange.Y,NewYValue,StandardCurrentLocation.Z);
		}
	}
	
	//检测当前的标准位置的Y值是否在范围内
	if (StandardCurrentLocation.Y<YRange.X&&StandardCurrentLocation.Y>YRange.Y)
	{
		//Y不处于范围
		
		//计算当前的比例X:Y
        const float CurrentScale=StandardCurrentLocation.X/StandardCurrentLocation.Y;
        
        //进一步确定,标准位置的Y值小于限定的最小值
        if (StandardCurrentLocation.Y<YRange.X)
        {
        	//校准标准位置的Y值为限定的最小值,同时等比例更改X的值
        	const float NewXValue=YRange.X*CurrentScale;
        	StandardCurrentLocation=FVector(NewXValue,YRange.X,StandardCurrentLocation.Z);
        }
        
        //进一步确定,标准位置的Y值大于限定的最大值
        if (StandardCurrentLocation.Y>YRange.Y)
        {
        	//校准标准位置的X值为限定的最小大值,同时等比例更改Y的值
        	const float NewXValue=YRange.Y*CurrentScale;
        	StandardCurrentLocation=FVector(NewXValue,YRange.Y,StandardCurrentLocation.Z);
        }
	}

	//下一步目的:此时标准位置处理完毕,再进行转换到不标准的位置作为其返回值

	//获取中心点到当前标准位置的移动偏移向量
	CurrentOffstVector=StandardCurrentLocation-CentrePoint;

	//将标准的偏移向量转换为不标准的偏移向量
	OffsetVector=FRotator(0,0,-1*YawAngleOffset).RotateVector(CurrentOffstVector);

	//返回最终的位置
	return CentrePoint+OffsetVector;
}


#pragma endregion
