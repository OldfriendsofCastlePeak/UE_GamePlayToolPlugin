﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "CommonGamePlayToolPlugin/CommonGamePlayToolPlugin.h"
#include "CommonGamePlayToolPlugin/Interface/CommonManagerInterface.h"
#include "CommonBaseGameModeBase.generated.h"

class ACommonBaseManager;

UCLASS(Blueprintable,BlueprintType)
class COMMONGAMEPLAYTOOLPLUGIN_API ACommonBaseGameModeBase : public AGameModeBase,
															 public ICommonManagerInterface
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ACommonBaseGameModeBase()
	{
		// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
		PrimaryActorTick.bCanEverTick = true;
	}

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	
	/* 在编辑器显示屏幕打印 */
	UPROPERTY(EditAnywhere,Category="ACommonBaseGameModeBase|Message")
	uint8 bShowScreenMessageInEditor:1=1;

	/* 在打包后的游戏显示屏幕打印 */
	UPROPERTY(EditAnywhere,Category="ACommonBaseGameModeBase|Message")
	uint8 bShowScreenMessageInGame:1=0;
	
	/* 用于储存多个Manager */
	UPROPERTY(BlueprintReadWrite,Category="ACommonBaseGameModeBase")
	TMap<TSubclassOf<ACommonBaseManager>,ACommonBaseManager*>ManagerMap;
	
	/* 用于记录需要注册的Manager类型数量 */
	UPROPERTY(BlueprintReadWrite,EditAnywhere,Category="ACommonBaseGameModeBase")
	uint8 ManagerTypeNum=10;
	
	/* 获取指定管理类的对象 */
	UFUNCTION(BlueprintCallable,Category="ACommonBaseGameModeBase")
	ACommonBaseManager* GetClassManager(const TSubclassOf<ACommonBaseManager>ManagerClass);
	
	/* 接收Manager注册 */
	virtual void ReceiveManagerRegisterEvent_Implementation(TSubclassOf<ACommonBaseManager> ManagerClass,ACommonBaseManager* ManagerObject)override;

#pragma region GameMode内部使用方法
private:
	/* 设置屏幕消息显示,用于绑定委托 */
	void SetScreenMessageShow(UWorld* Value);
#pragma endregion


	
};
