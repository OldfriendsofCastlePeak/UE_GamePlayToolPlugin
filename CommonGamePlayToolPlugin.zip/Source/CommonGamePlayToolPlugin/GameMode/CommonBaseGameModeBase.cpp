#include "CommonBaseGameModeBase.h"
#include "CommonGamePlayToolPlugin/Manager/CommonBaseManager.h"

void ACommonBaseGameModeBase::BeginPlay()
{
	Super::BeginPlay();

	//屏幕显示
	FWorldDelegates::OnPostWorldCreation.AddUObject(this,&ACommonBaseGameModeBase::SetScreenMessageShow);
}

void ACommonBaseGameModeBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}



void ACommonBaseGameModeBase::ReceiveManagerRegisterEvent_Implementation(TSubclassOf<ACommonBaseManager> ManagerClass,ACommonBaseManager* ManagerObject)
{
	//向Map中添加ACommonBaseManager对象
	ManagerMap.Add(ManagerClass,ManagerObject);

	//满足条件时,通知所有Manager注册完毕
	if (ManagerMap.Num()>=ManagerTypeNum)
	{
		TArray<ACommonBaseManager*>ManagerObjectArray;
		ManagerMap.GenerateValueArray(ManagerObjectArray);

		//执行接口通知所有Manager注册完毕
		for (ACommonBaseManager* TemManager:ManagerObjectArray)
		{
			Execute_AllManagerRegisterCompleteEvent(TemManager);
		}
	}
}



ACommonBaseManager* ACommonBaseGameModeBase::GetClassManager(const TSubclassOf<ACommonBaseManager> ManagerClass)
{
	{
		if (!ManagerClass->IsValidLowLevel()) return nullptr;
		if (ManagerMap.Find(ManagerClass))
		{
			return *ManagerMap.Find(ManagerClass);
		}
		return nullptr;
	}
}

#pragma region GameMode内部使用方法

void ACommonBaseGameModeBase::SetScreenMessageShow(UWorld* Value)
{
#if WITH_EDITOR
	GAreScreenMessagesEnabled = bShowScreenMessageInEditor;
	GEngine->bEnableOnScreenDebugMessages=bShowScreenMessageInEditor;
	UE_LOG(FCommonGamePlayLog,Display,TEXT("在编辑器下执行,设置屏幕显示:%d"),bShowScreenMessageInEditor);
#else
	GAreScreenMessagesEnabled = bShowScreenMessageInGame;
	GEngine->bEnableOnScreenDebugMessages=bShowScreenMessageInGame;
	UE_LOG(FCommonGamePlayLog,Display,TEXT("在非编辑器下执行,设置屏幕显示:%d"),bShowScreenMessageInGame);
#endif
}
#pragma endregion
