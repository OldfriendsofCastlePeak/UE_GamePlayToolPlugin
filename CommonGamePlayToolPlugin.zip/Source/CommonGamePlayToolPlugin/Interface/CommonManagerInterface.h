﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "CommonManagerInterface.generated.h"

class ACommonBaseManager;

// This class does not need to be modified.
UINTERFACE(BlueprintType,MinimalAPI)
class UCommonManagerInterface : public UInterface
{
	GENERATED_BODY()
};

/**
 * 
 */
class COMMONGAMEPLAYTOOLPLUGIN_API ICommonManagerInterface
{
	GENERATED_BODY()

	// Add interface functions to this class. This is the class that will be inherited to implement this interface.
public:
	/* 初始化Manager */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ICommonManagerInterface")
	void InitializeManagerEvent();
	virtual void InitializeManagerEvent_Implementation(){}
	
	/* 注册Manager */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ICommonManagerInterface")
	void RegisterManagerEvent();
	virtual void RegisterManagerEvent_Implementation(){}

	/* 接收Manager注册 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ICommonManagerInterface")
	void ReceiveManagerRegisterEvent(TSubclassOf<ACommonBaseManager> ManagerClass,ACommonBaseManager* ManagerObject);
	virtual void ReceiveManagerRegisterEvent_Implementation(TSubclassOf<ACommonBaseManager> ManagerClass,ACommonBaseManager* ManagerObject){}
	
	/* 所有Manager注册完毕事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ICommonManagerInterface")
	void AllManagerRegisterCompleteEvent();
	virtual void AllManagerRegisterCompleteEvent_Implementation(){}

	/* 通知Manager初始关卡加载完毕事件 */
	UFUNCTION(BlueprintNativeEvent,BlueprintCallable,Category="ICommonManagerInterface")
	void InitializeLevelCompleteEvent();
	virtual void InitializeLevelCompleteEvent_Implementation(){}
};
