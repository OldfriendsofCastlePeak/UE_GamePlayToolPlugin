﻿#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Engine/DataTable.h"
#include "DataTableType.h"
#include "DataType.generated.h"


/* 通用的基本DataAsset类型 */
UCLASS(Blueprintable,BlueprintType,Abstract)
class COMMONGAMEPLAYTOOLPLUGIN_API UCommonBaseData : public UDataAsset
{
	GENERATED_BODY()
public:
	/* 数据的标识名 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="UCommonBaseData")
	FName DataAssetName;

	/* 以Map形式存储子数据 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="UCommonBaseData")
	TMap<FName,UDataAsset*>ChildDataAssetMap;

	/* 以Array形式储存子数据 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="UCommonBaseData")
	TArray<UDataAsset*>ChildDataAssetArray;
};

//项目数据配置
UCLASS(Blueprintable,BlueprintType)
class COMMONGAMEPLAYTOOLPLUGIN_API UProjectConfigData : public UCommonBaseData
{
	GENERATED_BODY()
public:
	/* 相机参数 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectConfigData")
	FCameraTableStruct CameraInfo;

	/* 环境参数 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectConfigData")
	FEnvTableStruct EnvInfo;

	/* 关卡信息 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectConfigData")
	FLevelTableStruct LevelInfo;
};

//项目各个模块配置
UCLASS(Blueprintable,BlueprintType)
class COMMONGAMEPLAYTOOLPLUGIN_API UProjectModuleConfigData:public UCommonBaseData
{
	GENERATED_BODY()
public:
	/* 相机参数 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectModuleConfigData")
	FCameraTableStruct CameraInfo;

	/* 环境参数 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectModuleConfigData")
	FEnvTableStruct EnvInfo;

	/* 关卡信息 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectModuleConfigData")
	FLevelTableStruct LevelInfo;

	/* 相机详细数据表,用于配置定义多参数的相机移动功能 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectModuleConfigData")
	UDataTable* DetailCameraTable=nullptr;

	/* 简单功能的数据表 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectModuleConfigData")
	UDataTable* SimpleFunctionTable=nullptr;
	
	/* 配置数据表 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="UProjectModuleConfigData")
	TMap<FName,UDataTable*> DataTableAsset;
};












































