// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

#include "DataTableType.generated.h"

/* 用于处理相机相关属性的结构体 */
USTRUCT(Blueprintable,BlueprintType)
struct FTableBaseStruct:public FTableRowBase
{
	GENERATED_BODY()

	/* 额外属性配置 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="FTableBaseStruct")
	TMap<FName,FString> Extra_Data;
};

/* 用于项目模块各个条目相关属性的结构体,相当于组合:FCameraTableStruct、FEnvTableStruct、FLevelTableStruct、FEventTableStruct */
USTRUCT(Blueprintable,BlueprintType)
struct FAllItemTableStruct:public FTableBaseStruct
{
	GENERATED_BODY()
	
	/* 相机标识符 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	FName CameraIdentify;

	/* 使用CameraActor的FOV */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bUseCameraActorFOV:1=1;
	
	/* 相机FOV */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="!bUseCameraActorFOV"))
	float FOV=90;

	/* 相机的混合时间 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	float ViewBlendTime=1.f;
	
	//当前状态下能否移动
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bCanMove:1=0;
    
	//当前状态下能否旋转
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bCanRotate:1=0;

	//能否自动旋转
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bCanAutoRotate:1=0;

	/* 能否进行视角缩放,一般情况下,这将限制弹簧臂的缩放 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bCanViewScale:1=0;

	/* 进入当前条目时需要显示的关卡 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FLevelTableStruct")
	TArray<TSoftObjectPtr<UWorld>>ShowLevel;

	/* 进入当前条目时需要隐藏的关卡 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FLevelTableStruct")
	TArray<TSoftObjectPtr<UWorld>>HiddenLevel;

	/* 要调用的方法名 */
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FEventTableStruct")
    FName FunctionName;
};

/* 用于处理视角变化相关属性的结构体 */
USTRUCT(Blueprintable,BlueprintType)
struct FCameraTableStruct:public FTableBaseStruct
{
	GENERATED_BODY()
#pragma region 相机位置旋转
	
	/* 是否使用相机的Actor的旋转和角度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bUseCameraTransform:1=1;
	
	/* 相机标识符 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="bUseCameraTransform"))
	FName CameraIdentify;

	/* 设置的Pawn的位置 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="!bUseCameraTransform"))
	FVector PawnLocation=FVector::Zero();

	/* 设置的Pawn的位置 */
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="!bUseCameraTransform"))
    FRotator PawnRotation=FRotator::ZeroRotator;

	/* 设置的Pawn的视角缩放 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="!bUseCameraTransform"))
	float ViewScaleLength=0.f;

#pragma endregion
	
	/* 使用CameraActor的FOV */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bUseCameraActorFOV:1=1;
	
	/* 自定义的相机FOV */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="!bUseCameraActorFOV"))
	float FOV=90;

	/* 相机的混合时间 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	float ViewBlendTime=1.f;
	
	/* 当前状态下能否移动 */
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
    uint8 bCanMove:1=0;

	/* 是否限制移动范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="bCanMove"))
	uint8 bLimitMoveRange:1=0;

	/* 限制的X移动范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="bLimitMoveRange"))
	FVector2D XMoveRange=FVector2D::Zero();
	
	/* 限制的Y移动范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="bLimitMoveRange"))
	FVector2D YMoveRange=FVector2D::Zero();

	/* 限制的Z移动范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="bLimitMoveRange"))
	FVector2D ZMoveRange=FVector2D::Zero();
	
    //当前状态下能否旋转
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
    uint8 bCanRotate:1=0;

	//限制的Pitch值范围
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct",meta=(EditCondition="bCanRotate"))
	FVector2D PitchRotateRange=FVector2D(-89,-1);
	
	//能否自动旋转
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bCanAutoRotate:1=0;

	/* 能否进行视角缩放,一般情况下,这将限制弹簧臂的缩放 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct|ViewScale")
	uint8 bCanViewScale:1=0;

	/* 是否限制视角缩放 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct|ViewScale")
	uint8 bCanLimitViewScale:1=0;
	
	/* 弹簧臂的Pawn的视角缩放范围 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct|ViewScale",meta=(EditCondition="bCanLimitViewScale"))
	FVector2D SpringArmCameraViewScaleRange=FVector2D::Zero();
	
	//当前状态下能否中断播放Sequence
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FCameraTableStruct")
	uint8 bCanBreakSequencePlay:1=0;
};

/* 用于记录环境相关属性的结构体 */
USTRUCT(Blueprintable,BlueprintType)
struct FEnvTableStruct:public FTableBaseStruct
{
	GENERATED_BODY()
	
	/* 光照时间 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FEnvTableStruct")
	float LightTime=1750;

	/* 太阳角度 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FEnvTableStruct")
	float SunAngle=250.f;

	/* 后期盒子曝光补偿 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FEnvTableStruct")
	float ExposeLightValue=0.0f;
};

/* 用于记录关卡数据相关属性的结构体 */
USTRUCT(Blueprintable,BlueprintType)
struct FLevelTableStruct:public FTableBaseStruct
{
	GENERATED_BODY()
	
	/* 进入当前条目时需要显示的关卡 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FLevelTableStruct")
	TArray<TSoftObjectPtr<UWorld>>ShowLevel;

	/* 进入当前条目时需要隐藏的关卡 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FLevelTableStruct")
	TArray<TSoftObjectPtr<UWorld>>HiddenLevel;
	
};

/* 用于调用额外的方法 */
USTRUCT(Blueprintable,BlueprintType)
struct FEventTableStruct:public FTableBaseStruct
{
	GENERATED_BODY()
	
	/* 要调用的方法名 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="FEventTableStruct")
	FName FunctionName;
};



