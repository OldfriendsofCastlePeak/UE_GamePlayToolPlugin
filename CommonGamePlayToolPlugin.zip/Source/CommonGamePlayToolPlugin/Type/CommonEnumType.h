#pragma once
#include "CoreMinimal.h"
#include "CommonEnumType.generated.h"

/* 用于声明移动方式类型 */
UENUM(BlueprintType)
enum EMoveWayType : uint8
{
	/* 鸟瞰移动 */
	BirdView,

	/* 第一人称移动 */
	FirstView,

	/* 鼠标滚轮缩放形式的移动 */
	ZoomView,

	/*  */
	None
};

/* 鸟瞰视角操作类型 */
UENUM(BlueprintType)
enum EBirdViewOperactionType : uint8
{
	/* 标准的移动 */
	Normal,

	/* 仅旋转 */
	OnlyRotate,

	/* 仅移动 */
	OnlyMove
};
