﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "PlaySequenceToolComponent.h"
#include "Runtime/LevelSequence/Public/LevelSequenceActor.h"
#include "LevelSequencePlayer.h"
#include "Misc/QualifiedFrameTime.h"
#include "Misc/FrameTime.h"


// Sets default values for this component's properties
UPlaySequenceToolComponent::UPlaySequenceToolComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UPlaySequenceToolComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...

	
}


// Called every frame
void UPlaySequenceToolComponent::TickComponent(float DeltaTime, ELevelTick TickType,
                                               FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

void UPlaySequenceToolComponent::StopPlayLevelSequence_Implementation()
{
	//先检查SequencePlayer是否处于无效状态
	if (!GetLevelSequencePlayer()) return;
	
	//先检查SequencePlayer是否处于播放状态
	if (!GetLevelSequencePlayer()->IsPlaying()||GetLevelSequencePlayer()->IsPaused()||GetLevelSequencePlayer()->IsReversed()) return;
	
	//退出播放
	bPlaying=0;
	GetLevelSequencePlayer()->Stop();

}

void UPlaySequenceToolComponent::PausePlayLevelSequence_Implementation()
{
	//如果Sequence当前处于播放状态则暂停
	if (GetLevelSequencePlayer()->IsPlaying()||GetLevelSequencePlayer()->IsReversed()) GetLevelSequencePlayer()->Pause();
}

void UPlaySequenceToolComponent::ResumePlayLevelSequence_Implementation()
{
	//如果Sequence当前处于暂停状态则播放
	if (GetLevelSequencePlayer()->IsPaused()) GetLevelSequencePlayer()->Play();
}

void UPlaySequenceToolComponent::ResumeReversePlayLevelSequence_Implementation()
{
	//如果Sequence当前处于暂停状态则播放
	if (GetLevelSequencePlayer()->IsPaused()) GetLevelSequencePlayer()->PlayReverse();
}

ULevelSequencePlayer* UPlaySequenceToolComponent::GetLevelSequencePlayer()
{
	//初始化先创建一个ULevelSequencePlayer
	if (!SequencePlayer)
	{
		if (!CurrentSequence) return nullptr;
		
		//构建一个ALevelSequenceActor对象
		ALevelSequenceActor* TemLevelSequenceActor=NewObject<ALevelSequenceActor>();
		//构建一个空的ULevelSequence对象
		SequencePlayer=ULevelSequencePlayer::CreateLevelSequencePlayer(this,CurrentSequence,SequencePlaybackSettings,TemLevelSequenceActor);

		//绑定委托
		SequencePlayer->OnPlay.AddDynamic(this,&UPlaySequenceToolComponent::OnSequencePlay_Internal);
		SequencePlayer->OnPlayReverse.AddDynamic(this,&UPlaySequenceToolComponent::OnSequenceReversePlay_Internal);
		SequencePlayer->OnStop.AddDynamic(this,&UPlaySequenceToolComponent::OnSequenceStop_Internal);
		SequencePlayer->OnPause.AddDynamic(this,&UPlaySequenceToolComponent::OnSequencePause_Internal);
		SequencePlayer->OnFinished.AddDynamic(this,&UPlaySequenceToolComponent::OnSequenceFinalPlay_Internal);
	}
	return SequencePlayer;
}

void UPlaySequenceToolComponent::PlayLevelSequence(
	ULevelSequence* InLevelSequenceAsset,
	const FName Name)
{
	//检测资源是否有效
	if (!InLevelSequenceAsset) return;

	CurrentSequence=InLevelSequenceAsset;
	
	CurrentSequenceName=Name;
	
	//检测要播放的关卡序列是否和当前的一致
	if (InLevelSequenceAsset!=GetLevelSequencePlayer()->GetSequence())
	{
		if (GetLevelSequencePlayer()->IsPlaying()||GetLevelSequencePlayer()->IsReversed())
		{
			//停止播放动画序列,这里退出不会调用退出委托
			GetLevelSequencePlayer()->Stop();
		}
		//更新要播放的Sequence资源
		GetLevelSequencePlayer()->Initialize(InLevelSequenceAsset,GetComponentLevel(),CameraSettings);
	}
	else
	{
		if (!bResumePlay)
		{
			GetLevelSequencePlayer()->SetPlaybackPosition(FMovieSceneSequencePlaybackParams());
		}
	}

	GetLevelSequencePlayer()->Play();
	bPlaying=1;
}

void UPlaySequenceToolComponent::PlayActorLevelSequence(
	ALevelSequenceActor* InLevelSequenceActor,
	const FName Name)
{
	//检查传入的ALevelSequenceActor是否有效.
	if (InLevelSequenceActor==nullptr||InLevelSequenceActor->LevelSequenceAsset==nullptr) return;

	CurrentSequence=InLevelSequenceActor->LevelSequenceAsset;
	
	CurrentSequenceName=Name;
	
	//检测要播放的关卡序列是否和当前的一致
	if (InLevelSequenceActor->LevelSequenceAsset!=GetLevelSequencePlayer()->GetSequence())
	{
		if (GetLevelSequencePlayer()->IsPlaying()||GetLevelSequencePlayer()->IsReversed())
		{
			//停止播放动画序列,这里退出不会调用退出委托
			GetLevelSequencePlayer()->Stop();
		}
		//更新要播放的Sequence资源
		GetLevelSequencePlayer()->Initialize(InLevelSequenceActor->LevelSequenceAsset,GetComponentLevel(),CameraSettings);
	}

	//播放动画序列
	GetLevelSequencePlayer()->Play();
	bPlaying=1;
}

void UPlaySequenceToolComponent::ReversePlayLevelSequence(
	ULevelSequence* InLevelSequenceAsset,
	const FName Name)
{
	//检查传入的ALevelSequenceActor是否有效.
	if (InLevelSequenceAsset==nullptr) return;

	CurrentSequence=InLevelSequenceAsset;
	
	CurrentSequenceName=Name;
	
	//检测要播放的关卡序列是否和当前的一致
	if (InLevelSequenceAsset!=GetLevelSequencePlayer()->GetSequence())
	{
		if (GetLevelSequencePlayer()->IsPlaying()||GetLevelSequencePlayer()->IsReversed())
		{
			//停止播放动画序列,这里退出不会调用退出委托
			GetLevelSequencePlayer()->Stop();
		}
		//更新要播放的Sequence资源
		GetLevelSequencePlayer()->Initialize(InLevelSequenceAsset,GetComponentLevel(),CameraSettings);
	}
	else
	{
		if (!bResumePlay)
		{
			if (GetLevelSequencePlayer()->IsPlaying()||GetLevelSequencePlayer()->IsReversed())
			{
				GetLevelSequencePlayer()->SetPlaybackPosition(FMovieSceneSequencePlaybackParams());
			}
		}
	}

	//播放动画序列
	GetLevelSequencePlayer()->PlayReverse();
	bPlaying=1;
}

void UPlaySequenceToolComponent::ReversePlayActorLevelSequence(
	ALevelSequenceActor* LevelSequenceActor,
	const FName Name)
{
	//检查传入的ALevelSequenceActor是否有效.
	if (LevelSequenceActor==nullptr||LevelSequenceActor->LevelSequenceAsset==nullptr) return;

	CurrentSequence=LevelSequenceActor->LevelSequenceAsset;
	
	CurrentSequenceName=Name;
	
	//检测要播放的关卡序列是否和当前的一致
	if (LevelSequenceActor->LevelSequenceAsset!=GetLevelSequencePlayer()->GetSequence())
	{
		if (GetLevelSequencePlayer()->IsPlaying()||GetLevelSequencePlayer()->IsReversed())
		{
			//停止播放动画序列,这里退出不会调用退出委托
			GetLevelSequencePlayer()->Stop();
		}
		//更新要播放的Sequence资源
		GetLevelSequencePlayer()->Initialize(LevelSequenceActor->LevelSequenceAsset,GetComponentLevel(),CameraSettings);
	}

	//播放动画序列
	GetLevelSequencePlayer()->PlayReverse();
	bPlaying=1;
}

#pragma region 用于绑定委托的间接使用函数
void UPlaySequenceToolComponent::OnSequencePlay_Internal()
{
	StartPlaySequenceEvent.Broadcast(CurrentSequenceName);
}

void UPlaySequenceToolComponent::OnSequenceReversePlay_Internal()
{
	StartReversePlaySequence.Broadcast(CurrentSequenceName);
}

void UPlaySequenceToolComponent::OnSequenceStop_Internal()
{
	StopPlaySequence.Broadcast(CurrentSequenceName);
}

void UPlaySequenceToolComponent::OnSequencePause_Internal()
{
	PausePlaySequence.Broadcast(CurrentSequenceName);
}

void UPlaySequenceToolComponent::OnSequenceFinalPlay_Internal()
{
	FinshPlaySequence.Broadcast(CurrentSequenceName);
	
}
#pragma endregion


