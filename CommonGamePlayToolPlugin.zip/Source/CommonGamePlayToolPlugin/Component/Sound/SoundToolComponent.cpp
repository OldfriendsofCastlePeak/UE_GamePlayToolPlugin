﻿// // Fill out your copyright notice in the Description page of Project Settings.
//
//
// #include "SoundToolComponent.h"
//
// #include "Components/AudioComponent.h"
//
//
// // Sets default values for this component's properties
// USoundToolComponent::USoundToolComponent()
// {
// 	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
// 	// off to improve performance if you don't need them.
// 	PrimaryComponentTick.bCanEverTick = true;
//
// 	// ...
// }
//
//
// // Called when the game starts
// void USoundToolComponent::BeginPlay()
// {
// 	Super::BeginPlay();
//
// 	// ...
// 	
// }
//
//
// // Called every frame
// void USoundToolComponent::TickComponent(float DeltaTime, ELevelTick TickType,
//                                         FActorComponentTickFunction* ThisTickFunction)
// {
// 	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
// 	// ...
// }
// #pragma region 音频控制
// UAudioComponent* USoundToolComponent::GetAudioComponent()
// {
// 	if (!AudioComponent)
// 	{
// 		//创建组件
// 		AudioComponent=NewObject<UAudioComponent>(this);
// 		AudioComponent->RegisterComponent();
//
// 		//绑定委托
// 		AudioComponent->OnAudioFinished.AddDynamic(this,&USoundToolComponent::Call_AudioPlayFinshEvent);
// 		AudioComponent->OnAudioPlaybackPercent.AddDynamic(this,&USoundToolComponent::Call_AudioPlayProgressEvent);
// 	}
// 	return AudioComponent;
// }
//
// void USoundToolComponent::PlayAudioAsset(USoundWave* SoundAsset)
// {
// 	GetAudioComponent()->SetSound(SoundAsset);
// 	GetAudioComponent()->Play(0);
// }
//
// #pragma endregion
//
// #pragma region 用于内部使用的方法
// void USoundToolComponent::Call_AudioPlayFinshEvent()
// {
// 	AudioPlayFinshEvent.Broadcast();
// }
//
// void USoundToolComponent::Call_AudioPlayProgressEvent(const USoundWave* SoundWave,const float Value)
// {
// 	AudioPlayProgressEvent.Broadcast(Value);
// }
//
//
// #pragma endregion
//
//
//
//
//
//
//
//
//
//
//
//
//
