﻿// // Fill out your copyright notice in the Description page of Project Settings.
//
// #pragma once
//
// #include "CoreMinimal.h"
// #include "Components/ActorComponent.h"
// #include "SoundToolComponent.generated.h"
//
//
// UCLASS(ClassGroup=(CommonToolComponent), meta=(BlueprintSpawnableComponent),Blueprintable,BlueprintType)
// class COMMONGAMEPLAYTOOLPLUGIN_API USoundToolComponent : public UActorComponent
// {
// 	GENERATED_BODY()
//
// public:
// 	// Sets default values for this component's properties
// 	USoundToolComponent();
//
// protected:
// 	// Called when the game starts
// 	virtual void BeginPlay() override;
//
// public:
// 	// Called every frame
// 	virtual void TickComponent(float DeltaTime, ELevelTick TickType,
// 	                           FActorComponentTickFunction* ThisTickFunction) override;
// #pragma region 声明委托
// 	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FSoundToolDelegate_One_Float,float,Value);
// 	DECLARE_DYNAMIC_MULTICAST_DELEGATE(FSoundToolDelegate);
//
// 	/* 音频文件播放结束 */
// 	UPROPERTY(BlueprintAssignable,BlueprintCallable)
// 	FSoundToolDelegate AudioPlayFinshEvent;
// 	
// 	/* 音频文件播放进度 */
// 	UPROPERTY(BlueprintAssignable,BlueprintCallable)
// 	FSoundToolDelegate_One_Float AudioPlayProgressEvent;
// 	
// #pragma endregion
// 	/* 音频组件,用于播放UE的声音资源文件 */
// 	// UPROPERTY(BlueprintReadOnly,Category="USoundToolComponent")
// 	// UAudioComponent* AudioComponent=nullptr;
//
// #pragma region 音频控制
// public:
// 	/* 获取音频播放组件 */
// 	UFUNCTION(BlueprintPure,Category="USoundToolComponent")
// 	UAudioComponent* GetAudioComponent();
//
// 	UFUNCTION(BlueprintCallable,Category="USoundToolComponent")
// 	void PlayAudioAsset(USoundWave* SoundAsset);
// #pragma endregion	
//
// #pragma region 用于内部使用的方法
// 	UFUNCTION()
// 	void Call_AudioPlayFinshEvent();
//
// 	UFUNCTION()
// 	void Call_AudioPlayProgressEvent(const USoundWave* SoundWave,const float Value);
// 	
// #pragma endregion
// 	
// };
