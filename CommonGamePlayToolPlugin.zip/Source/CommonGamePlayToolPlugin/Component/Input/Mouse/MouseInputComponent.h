﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "../InputBaseComponent.h"
#include "MouseInputComponent.generated.h"


UCLASS(ClassGroup=(CommonToolComponent), meta=(BlueprintSpawnableComponent))
class COMMONGAMEPLAYTOOLPLUGIN_API UMouseInputComponent : public UInputBaseComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UMouseInputComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType,
	                           FActorComponentTickFunction* ThisTickFunction) override;

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FMouseInput_FVector2D,FVector2D,Value);
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FMouseInput_Float1D,float,Value);
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FMouseInput_Bool,bool,Value);
	
	/* 用来存放鼠标输入相关的UInputMappingContext */
	UPROPERTY(BlueprintReadWrite,Category="ACommonBasePawn|Input")
	UInputMappingContext* MouseInputMappingContextMap=nullptr;

	/* 用来存放鼠标输入相关的UInputAction的TMap */
	UPROPERTY(BlueprintReadWrite,Category="ACommonBasePawn|Input")
	TMap<FName,UInputAction*> MouseInputActionMap;

	/* 开始输入接口 */
	virtual void RegisterInputEvent_Implementation() override;
	virtual void UnRegisterInputEvent_Implementation() override;
	/* 结束输入接口 */
	
	/* 鼠标XY轴输入委托 */
	UPROPERTY(BlueprintAssignable,Category="UMouseInputComponent|MouseInput")
	FMouseInput_FVector2D MouseXYInput;

	/* 鼠标滚轮输入委托 */
	UPROPERTY(BlueprintAssignable,Category="UMouseInputComponent|MouseInput")
	FMouseInput_Float1D MouseWheelInput;

	/* 鼠标左键输入委托 */
	UPROPERTY(BlueprintAssignable,Category="UMouseInputComponent|MouseInput")
	FMouseInput_Bool MouseLeftButtonInput;

	/* 鼠标右键输入委托 */
	UPROPERTY(BlueprintAssignable,Category="UMouseInputComponent|MouseInput")
	FMouseInput_Bool MouseRightButtonInput;
	
	void MouseXYMove_Internal(const FInputActionInstance& Value) ;
	void MouseWheel_Internal(const FInputActionInstance& Value);
	void MouseLeft_Internal(const FInputActionInstance& Value);
	void MouseRight_Internal(const FInputActionInstance& Value);
};
