// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/GameplayStatics.h"
#include "../GameMode/CommonBaseGameModeBase.h"
#include "CommonGamePlayToolPlugin/Interface/CommonManagerInterface.h"
#include "CommonBaseManager.generated.h"

/*
* 该Actor用于作为Manager的基础类型
 */
UCLASS(Blueprintable,BlueprintType,Abstract)
class COMMONGAMEPLAYTOOLPLUGIN_API ACommonBaseManager : public AActor,
														public ICommonManagerInterface
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ACommonBaseManager()
	{
		// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
		PrimaryActorTick.bCanEverTick = false;
	}

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override
	{
		Super::BeginPlay();

		//执行Manager的注册
		Execute_RegisterManagerEvent(this);
		
		//默认在BeginPlay中初始化
		Execute_InitializeManagerEvent(this);
	}

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override
	{
		Super::Tick(DeltaTime);
	}

	//开始ICommonManagerInterface接口
	virtual void InitializeManagerEvent_Implementation()override{}
	virtual void RegisterManagerEvent_Implementation()override
	{
		if (UGameplayStatics::GetGameMode(this)->IsA(ACommonBaseGameModeBase::StaticClass()))
		{
			//调用GameMode上接口完成注册
			Cast<ACommonBaseGameModeBase>(UGameplayStatics::GetGameMode(this))->Execute_ReceiveManagerRegisterEvent(UGameplayStatics::GetGameMode(this),GetClass(),this);
		}
	}
	virtual void AllManagerRegisterCompleteEvent_Implementation()override{}
	virtual void InitializeLevelCompleteEvent_Implementation()override{}
	//结束ICommonManagerInterface接口
	
};