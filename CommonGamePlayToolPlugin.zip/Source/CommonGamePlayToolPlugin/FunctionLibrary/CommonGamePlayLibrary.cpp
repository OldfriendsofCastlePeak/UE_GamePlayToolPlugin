﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CommonGamePlayLibrary.h"

#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "CommonGamePlayToolPlugin/CommonGamePlayToolPlugin.h"

#pragma region 视角函数方法
float UCommonGamePlayLibrary::GetCameraActorFOV(const AActor* CameraActor)
{
	//先检测传入的ACameraActor是否有效
	if (!CameraActor)
	{
		UE_LOG(FCommonGamePlayLog,Warning,TEXT("CameraActor 无效,返回默认FOV值90"));
		return 90.f;
	}else
	{
		if (const ACameraActor* TemCameraActor=Cast<ACameraActor>(CameraActor))
		{
			//获取相机的FOV
			return TemCameraActor->GetCameraComponent()->FieldOfView;
		}else
		{
			UE_LOG(FCommonGamePlayLog,Warning,TEXT("CameraActor不是ACameraActor,返回默认FOV值90"));
			return 90.f;
		}
	}
}

void UCommonGamePlayLibrary::GetCameraActorTransformInfo(const AActor* CameraActor, FRotator& Rotator,
	FVector& Vector)
{
	if (!CameraActor)
	{
		UE_LOG(FCommonGamePlayLog,Warning,TEXT("CameraActor 无效,使用默认的转换"));
		Rotator=FRotator();
		Vector=FVector::Zero();
		return;
	}
	Rotator=CameraActor->GetActorRotation();
	Vector=CameraActor->GetActorLocation();
}

float UCommonGamePlayLibrary::GetCameraActorAspectRatio(const AActor* CameraActor)
{
	//先检测传入的ACameraActor是否有效
	if (!CameraActor)
	{
		UE_LOG(FCommonGamePlayLog,Warning,TEXT("CameraActor 无效,返回默认AspectRatio值1"));
		return 1.777778f;
	}else
	{
		if (const ACameraActor* TemCameraActor=Cast<ACameraActor>(CameraActor))
		{
			//获取相机的FOV
			return TemCameraActor->GetCameraComponent()->AspectRatio;
		}else
		{
			UE_LOG(FCommonGamePlayLog,Warning,TEXT("CameraActor不是ACameraActor,返回默认FOV值90"));
			return 1.777778f;
		}
	}
}

void UCommonGamePlayLibrary::SetCameraActorAspectRatio(ACameraActor* CameraActor,const bool bEnable)
{
	if (!CameraActor) return ;
	CameraActor->GetCameraComponent()->bConstrainAspectRatio=bEnable;
}
#pragma region 设置Actor位置
void UCommonGamePlayLibrary::SetActorZLocation(AActor* Value,const float ZValue)
{
	if (Value)
	{
		Value->SetActorLocation(FVector(Value->GetActorLocation().X,Value->GetActorLocation().Y,ZValue));
	}
}

float UCommonGamePlayLibrary::GetActorZLocation(const AActor* Value)
{
	if (Value)
	{
		return Value->GetActorLocation().Z;
	}
	return 0.f;
}

void UCommonGamePlayLibrary::SetComponentRelativeZLocation(USceneComponent* Value, const float ZValue)
{
	if (Value)
	{
		Value->SetRelativeLocation(FVector(Value->GetRelativeLocation().X,Value->GetRelativeLocation().Y,ZValue));
	}
}

float UCommonGamePlayLibrary::GetComponentRelativeActorZLocation(const USceneComponent* Value)
{
	if (Value)
	{
		return Value->GetRelativeLocation().Z;
	}
	return 0.f;
}

#pragma endregion

#pragma region 设置角度

void UCommonGamePlayLibrary::SetActorYawRotation(AActor* Value, const float YawValue)
{
	if (Value)
	{
		Value->SetActorRotation(FRotator(Value->GetActorRotation().Pitch,YawValue,Value->GetActorRotation().Roll));
	}
}

float UCommonGamePlayLibrary::GetActorYawRotation(const AActor* Value)
{
	if (Value)
	{
		return Value->GetActorRotation().Yaw;
	}
	return 0.f;
}

void UCommonGamePlayLibrary::SetActorPitchRotation(AActor* Value, const float PitchValue)
{
	if (Value)
	{
		Value->SetActorRotation(FRotator(PitchValue,Value->GetActorRotation().Yaw,Value->GetActorRotation().Roll));
	}
}

float UCommonGamePlayLibrary::GetActorPitchRotation(const AActor* Value)
{
	if (Value)
	{
		return Value->GetActorRotation().Pitch;
	}
	return 0.f;
}

void UCommonGamePlayLibrary::SetComponentRelativeYawRotation(USceneComponent* Value, const float YawValue)
{
	if (Value)
	{
		Value->SetRelativeRotation(FRotator(Value->GetRelativeRotation().Pitch,YawValue,Value->GetRelativeRotation().Roll));
	}
}

float UCommonGamePlayLibrary::GetComponentRelativeYawRotation(const USceneComponent* Value)
{
	if (Value)
	{
		return Value->GetRelativeRotation().Yaw;
	}
	return 0.f;
}

void UCommonGamePlayLibrary::SetComponentRelativePitchRotation(USceneComponent* Value, const float PitchValue)
{
	if (Value)
	{
		Value->SetRelativeRotation(FRotator(PitchValue,Value->GetRelativeRotation().Yaw,Value->GetRelativeRotation().Roll));
	}
}

float UCommonGamePlayLibrary::GetComponentRelativePitchRotation(const USceneComponent* Value)
{
	if (Value)
	{
		return Value->GetRelativeRotation().Pitch;
	}
	return 0.f;
}


#pragma endregion


bool UCommonGamePlayLibrary::IsInEditor()
{
	return GetWorld()->IsEditorWorld();
}

bool UCommonGamePlayLibrary::IsInGame()
{
	return GetWorld()->IsGameWorld();
}


#pragma endregion

#pragma region FName方法


bool UCommonGamePlayLibrary::NameIs(const FName& Value1,const FName Value2)
{
	return Value1==Value2;
}
#pragma endregion


#pragma region 显示或关闭调试信息
void UCommonGamePlayLibrary::SetScrrenMessageVisuality(const bool Visible)
{
	if (GEngine)
	{
		GEngine->bEnableOnScreenDebugMessages=Visible;
	}
}

#pragma endregion















