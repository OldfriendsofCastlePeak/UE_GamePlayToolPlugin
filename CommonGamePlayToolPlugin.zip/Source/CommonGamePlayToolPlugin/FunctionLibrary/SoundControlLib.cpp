﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "SoundControlLib.h"

bool USoundControlLib::SetSystemVolume(const int LeftChannel,const int RightChannel)
{
	const DWORD Volume=MAKEWORD(LeftChannel,RightChannel);

	//设置系统音量
	const UINT SetResultCode= waveOutSetVolume(0,Volume);
	
	if (SetResultCode==MMSYSERR_INVALHANDLE)
	{
		//无效句柄
		return false;
	}else if (SetResultCode==MMSYSERR_NODRIVER)
	{
		//没有设备驱动程序存在
		return false;
	}else if (SetResultCode==MMSYSERR_NOMEM)
	{
		//无法分配或锁定内存
		return false;
	}else if (SetResultCode==MMSYSERR_NOTSUPPORTED)
	{
		//功能不支持
		return false;
	}
	
	return true;
}

bool USoundControlLib::GetSystemVolume(int& LeftChannel,int& RightChannel)
{
	DWORD Volume=0;

	// 获取系统音量
	if (waveOutGetVolume(0, &Volume) != MMSYSERR_NOERROR) {
		return false;
	}

	//获取左右声道的音量
	LeftChannel=LOWORD(Volume);
	RightChannel=HIWORD(Volume);
	
	return true;
}
