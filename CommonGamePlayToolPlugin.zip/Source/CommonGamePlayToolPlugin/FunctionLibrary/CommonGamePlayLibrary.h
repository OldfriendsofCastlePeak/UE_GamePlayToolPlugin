﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "CommonGamePlayLibrary.generated.h"

/**
 * 此函数库用于GamePlay相关使用方法
 */
UCLASS()
class COMMONGAMEPLAYTOOLPLUGIN_API UCommonGamePlayLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
#pragma region 视角函数方法
public:
	/* 获取CameraActor的FOV值,传入空则默认返回90 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|View")
	static float GetCameraActorFOV(const AActor* CameraActor);

	/* 获取CameraActor的位置、角度 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|View")
	static void GetCameraActorTransformInfo(const AActor* CameraActor,FRotator& Rotator,FVector& Vector);

	/* 获取CameraActor的UCameraComponent的AspectRatio属性,传入无效则默认为1.777778f */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|View")
	static float GetCameraActorAspectRatio(const AActor* CameraActor);

	/* 设置CameraActor的UCameraComponent的AspectRatio属性 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|View")
	static void SetCameraActorAspectRatio(ACameraActor* CameraActor,const bool bEnable);
#pragma endregion

#pragma region 设置位置
public:
	/* 设置Actor在世界空间中的Z轴值 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Location")
	static void SetActorZLocation(AActor* Value,const float ZValue);

	/* 获取Actor在世界空间中的Z轴值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Location")
	static float GetActorZLocation(const AActor* Value);

	/* 设置组件相对位置的Z轴值 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Location")
	static void SetComponentRelativeZLocation(USceneComponent* Value,const float ZValue);

	/* 获取组件相对位置的Z轴值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Location")
	static float GetComponentRelativeActorZLocation(const USceneComponent* Value);
#pragma endregion

#pragma region 设置角度
public:
	/* 设置Actor在世界空间中的Yaw轴旋转值 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Rotation")
	static void SetActorYawRotation(AActor* Value,const float YawValue);

	/* 获取Actor在世界空间中的Yaw轴旋转值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Rotation")
	static float GetActorYawRotation(const AActor* Value);

	/* 设置Actor在世界空间中的Pitch轴旋转值 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Rotation")
	static void SetActorPitchRotation(AActor* Value,const float PitchValue);

	/* 获取Actor在世界空间中的Pitch轴旋转值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Rotation")
	static float GetActorPitchRotation(const AActor* Value);

	/* 设置Actor在世界空间中的Yaw轴旋转值 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Rotation")
	static void SetComponentRelativeYawRotation(USceneComponent* Value,const float YawValue);

	/* 获取Actor在世界空间中的Yaw轴旋转值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Rotation")
	static float GetComponentRelativeYawRotation(const USceneComponent* Value);

	/* 设置Actor在世界空间中的Pitch轴旋转值 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Rotation")
	static void SetComponentRelativePitchRotation(USceneComponent* Value,const float PitchValue);

	/* 获取Actor在世界空间中的Pitch轴旋转值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Rotation")
	static float GetComponentRelativePitchRotation(const USceneComponent* Value);
#pragma endregion

#pragma region 设置缩放
public:
	/* 设置Actor在世界空间中的Yaw轴旋转值 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Scale")
	static void SetActorZScale(AActor* Value,const float ZScale);

	/* 获取Actor在世界空间中的Yaw轴旋转值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Scale")
	static float GetActorZScale(const AActor* Value);

#pragma endregion
	
#pragma region FName方法
public:
	/* 检查Name是否等于某个值 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|Name",meta=(CompactNodeTitle="Is"))
	static bool NameIs(const FName& Value1,const FName Value2);
	
#pragma endregion
	
#pragma region 获取当前所处世界状态
	/* 当前是否在编辑器世界中 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|World")
	bool IsInEditor();

	/* 当前是否在打包后的世界中 */
	UFUNCTION(BlueprintPure,Category="CommonGamePlayLibrary|World")
	bool IsInGame();

#pragma endregion
	
#pragma region 显示或关闭调试信息
	/* 设置屏幕消息的可视性 */
	UFUNCTION(BlueprintCallable,Category="CommonGamePlayLibrary|Message")
	static void SetScrrenMessageVisuality(const bool Visible);
	
#pragma endregion
	
};
